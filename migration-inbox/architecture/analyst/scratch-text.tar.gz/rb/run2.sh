#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/bwt2
PYTHONPATH=. python3 /home/user/test1/analysis/ramp-benchmark/shallow_deep.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/points2.json --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/results2.jsonl >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/run2.log 2>&1
echo RB2DONE $(date -u +%H:%M) >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/run2.log
