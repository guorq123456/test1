#!/bin/bash
until grep -q RB3BOTDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/run3.log; do sleep 20; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/bwt2
PYTHONPATH=. python3 /home/user/test1/analysis/ramp-benchmark/shallow_deep.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/points3c.json --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/results3c.jsonl >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/run3c.log 2>&1
echo RB3CDONE $(date -u +%H:%M) >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rb/run3c.log
