#!/bin/bash
# after the pirate mirror reruns: the elf-t/ramp-t cell at 2ff3aca (without / with the elf-t-ramp-t models), same seed bank
until grep -q "PIRMIRROR models done" /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/r17.log 2>/dev/null; do sleep 30; done
echo START $(date -u +%H:%M)
L=/home/user/test1/analysis/deck-league/league.py
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/erwt
SVSIM_PHASED=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/phased_noelframp PYTHONPATH=. python3 $L --decks elf-t ramp-t --pairings elf-t/ramp-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_2ff3aca_elframp_nomodel.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/elframp_nomodel.log 2>&1
echo ELFRAMP nomodel done $(date -u +%H:%M)
PYTHONPATH=. python3 $L --decks elf-t ramp-t --pairings elf-t/ramp-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_2ff3aca_elframp.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/elframp.log 2>&1
echo ELFRAMP models done $(date -u +%H:%M)
