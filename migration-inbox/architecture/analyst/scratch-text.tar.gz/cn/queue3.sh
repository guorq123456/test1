until grep -q QUEUE2DONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/queue2.log; do sleep 30; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt2
PYTHONPATH=.:/home/user/test1/analysis/card-value python3 /home/user/test1/analysis/card-value/realized.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sharp/v2_selfplay.jsonl analysis/selfplay/v2-mcts400-500games.jsonl.gz --items 1200 --k 4 --research 100 --next-search 30 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized_1e5141d.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized.log 2>&1
echo QUEUE3DONE
