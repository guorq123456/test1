#!/bin/bash
# after the elf-t mirror reruns: lethal probes (cheap banding) on the baseline and the 3effa47 no-model records
until grep -q "ELFMIRROR models done" /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log; do sleep 60; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfwt
export PYTHONPATH=.:/home/user/test1/analysis/deck-league
P=/home/user/test1/analysis/deck-league/probe_records.py
nice -n 10 python3 $P --pair elf-t/elf-t --cheap --workers 2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_elf_f631e14.jsonl /home/user/test1/analysis/deck-league/league_v2s_f631e14.jsonl.gz+/home/user/test1/analysis/deck-league/league_v2s_f631e14_mirror2.jsonl.gz
echo PROBE base done $(date -u +%H:%M)
nice -n 10 python3 $P --pair elf-t/elf-t --cheap --workers 2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_elf_3effa47_noelf.jsonl /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_3effa47_elfmirror_noelfmodel.jsonl.gz
echo PROBE noelf done $(date -u +%H:%M)
