#!/bin/bash
# after the container restart (00:17Z): mistakes analysis -> (probe resume, low priority) + K=32 resume -> salem_end -> E0
while kill -0 231 2>/dev/null; do sleep 30; done
echo MISTAKESDONE $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfwt
(PYTHONPATH=.:/home/user/test1/analysis/deck-league nice -n 10 python3 /home/user/test1/analysis/deck-league/probe_records.py --pair elf-t/elf-t --cheap --workers 2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_elf_f631e14.jsonl /home/user/test1/analysis/deck-league/league_v2s_f631e14.jsonl.gz+/home/user/test1/analysis/deck-league/league_v2s_f631e14_mirror2.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_resume.log 2>&1; echo PROBEDONE $(date -u +%H:%M) >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/r16.log) &
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt2
PYTHONPATH=.:/home/user/test1/analysis/card-value nice -n 10 python3 /home/user/test1/analysis/card-value/realized_end.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sharp/v2_selfplay.jsonl analysis/selfplay/v2-mcts400-500games.jsonl.gz --rows /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized_1e5141d.jsonl --items 400 --k 16 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized_end_k32_1e5141d.jsonl >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized_end_k32.log 2>&1
echo K32DONE $(date -u +%H:%M)
PYTHONPATH=.:/home/user/test1/analysis/card-value python3 /home/user/test1/analysis/card-value/salem_end.py /home/user/test1/analysis/mirror-regression/positions.json /home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json --k 16 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/salem_end_k32.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/salem_end.log 2>&1
echo SALEMENDDONE $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
export PYTHONPATH=.:/home/user/test1/analysis/deck-inference
python3 /home/user/test1/analysis/deck-inference/e0_gate.py --lists /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/infer --phase sprt --pairs 600 --seed 36000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_sprt.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_sprt.log 2>&1
echo E0SPRTDONE $(date -u +%H:%M)
python3 /home/user/test1/analysis/deck-inference/e0_gate.py --lists /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/infer --phase fixed --pairs 300 --seed 36500000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_fixed600.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_fixed600.log 2>&1
echo E0FIXEDDONE $(date -u +%H:%M)
