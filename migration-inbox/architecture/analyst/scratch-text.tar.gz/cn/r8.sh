#!/bin/bash
# after hold vs spend (21 rows) and the mirrors' second games (600 games): simulated mulligan stability
until [ "$(wc -l < /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/hold_vs_spend_k32.jsonl)" -ge 21 ] && [ "$(zcat /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_f631e14_mirror2.jsonl.gz 2>/dev/null | wc -l)" -ge 600 ]; do sleep 30; done
echo READY $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
PYTHONPATH=. python3 /home/user/test1/analysis/tournament-audit/mulligan_sim_check.py --stability --hands 50 --ns 4 8 16 --workers 4 > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mull/stability.txt 2>&1
echo STABILITYDONE $(date -u +%H:%M)
