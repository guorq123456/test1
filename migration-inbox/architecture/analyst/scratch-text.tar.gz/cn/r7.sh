#!/bin/bash
# after the deck league: hold vs spend on Salem's turns of the cell (K=32)
while pgrep -f "deck-league/league.py --pairs" > /dev/null; do sleep 60; done
echo LEAGUEDONE
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
PYTHONPATH=.:/home/user/test1/analysis/cross-turn:/home/user/test1/analysis/card-value:/home/user/test1/analysis/mirror-regression python3 /home/user/test1/analysis/cross-turn/hold_vs_spend.py /home/user/test1/analysis/mirror-regression/salem_games.json /home/user/test1/analysis/mirror-regression/evolve_probes.json --k 16 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/hold_vs_spend_k32.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/hold_vs_spend.log 2>&1
echo HOLDSPENDDONE
