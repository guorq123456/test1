until grep -q QUEUEDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/queue.log; do sleep 30; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt
PYTHONPATH=.:/home/user/test1/analysis/gate-runs python3 /home/user/test1/analysis/gate-runs/fixed_run.py --a "v2+crossn8z1r50" --b v2 --pairs 300 --seed 21250000 --workers 4 --every 100 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/fixed600_crossn8z1r50_vs_v2_seed21250000.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/f1.log 2>&1
echo QUEUE2DONE
