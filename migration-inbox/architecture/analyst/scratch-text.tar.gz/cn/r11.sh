#!/bin/bash
# after the v2s re-check: the C regret diagnostic, then the R vs D gates (mixed opponent pools), H1 -> fixed 600
until grep -q V2SDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/r9.log; do sleep 30; done
echo START $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
export PYTHONPATH=.:/home/user/test1/analysis/tournament-audit
PYTHONPATH=. python3 /home/user/test1/analysis/tournament-audit/mulligan_sim_check.py --regret --n 8 --hands 64 --workers 4 > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mull/regret.txt 2>&1
echo REGRETDONE $(date -u +%H:%M)
G=/home/user/test1/analysis/tournament-audit/mulligan_gate.py
gate () {   # name deck way seed opponents...
  local name=$1 deck=$2 way=$3 seed=$4; shift 4
  python3 $G --deck $deck --way $way --opponents "$@" --phase sprt --pairs 600 --seed $seed --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_sprt.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_sprt.log 2>&1
  echo "$name SPRT $(grep -o 'SPRT 停：H[01]' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_sprt.log) $(date -u +%H:%M)"
  if grep -q 'SPRT 停：H1' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_sprt.log; then
    python3 $G --deck $deck --way $way --opponents "$@" --phase fixed --pairs 300 --seed $((seed + 500000)) --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_fixed600.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_${name}_fixed600.log 2>&1
    echo "$name FIXED done $(date -u +%H:%M)"
  fi
}
gate elf elf-t rules 38000000 elf-t nemesis-t ramp-t pirate-t
gate pirate pirate-t rules 39000000 elf-t nemesis-t ramp-t pirate-t
gate ramp ramp-t rules 40000000 elf-t nemesis-t
gate nemesis nemesis-t rules:nem4 41000000 elf-t nemesis-t ramp-t pirate-t
echo ALLGATESDONE $(date -u +%H:%M)
