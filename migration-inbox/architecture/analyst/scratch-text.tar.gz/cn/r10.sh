#!/bin/bash
# after the v2s re-check: the C regret diagnostic, then the R vs D gate on the ramp-t mirror (SPRT, then fixed 600)
until grep -q V2SDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/r9.log; do sleep 30; done
echo START $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
PYTHONPATH=. python3 /home/user/test1/analysis/tournament-audit/mulligan_sim_check.py --regret --n 8 --hands 64 --workers 4 > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mull/regret.txt 2>&1
echo REGRETDONE $(date -u +%H:%M)
V=mcts:200+plan+learned+phased
PYTHONPATH=. python3 -m svsim.tools.gate --a "$V+mull=rules" --b "$V" --deck ramp-t --opponent ramp-t --h0 0.5 --h1 0.55 --max 1200 --seed 37000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_R_vs_D_ramp-t_sprt.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_R_vs_D_ramp-t_sprt.log 2>&1
echo SPRTDONE $(date -u +%H:%M)
PYTHONPATH=.:/home/user/test1/analysis/gate-runs python3 /home/user/test1/analysis/gate-runs/fixed_run.py --a "$V+mull=rules" --b "$V" --deck ramp-t --opponent ramp-t --pairs 300 --seed 37500000 --workers 4 --every 50 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_R_vs_D_ramp-t_fixed600.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_R_vs_D_ramp-t_fixed600.log 2>&1
echo FIXEDDONE $(date -u +%H:%M)
