#!/bin/bash
# after the opening gates: resume G_end K=32 (r6 then runs the discrimination experiment), then the E0 gate
until grep -q ALLGATESDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log; do sleep 60; done
echo GATESDONE $(date -u +%H:%M)
kill -CONT 17191 17193 17194 17195 17196
echo K32RESUMED $(date -u +%H:%M)
until grep -q SALEMENDDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/r6.log 2>/dev/null; do sleep 60; done
echo SALEMEND_SEEN $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
export PYTHONPATH=.:/home/user/test1/analysis/deck-inference
python3 /home/user/test1/analysis/deck-inference/e0_gate.py --lists /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/infer --phase sprt --pairs 600 --seed 36000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_sprt.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_sprt.log 2>&1
echo E0SPRTDONE $(date -u +%H:%M)
python3 /home/user/test1/analysis/deck-inference/e0_gate.py --lists /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/infer --phase fixed --pairs 300 --seed 36500000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_fixed600.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/e0_fixed600.log 2>&1
echo E0FIXEDDONE $(date -u +%H:%M)
