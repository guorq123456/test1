until grep -q QUEUE2DONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/queue2.log; do sleep 30; done
until [ -s /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/strong_rt_N.txt ]; do sleep 30; done
N=$(cat /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/strong_rt_N.txt)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt3
PYTHONPATH=. python3 -m svsim.tools.gate --a "mcts:$N+plan+learned+phased+crossn4z1rt" --b v2s --max 2000 --workers 4 --seed 22100000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/sprt_eq_mcts${N}_crossn4z1rt_vs_v2s_seed22100000.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/g5.log 2>&1
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt2
PYTHONPATH=.:/home/user/test1/analysis/card-value python3 /home/user/test1/analysis/card-value/realized.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sharp/v2_selfplay.jsonl analysis/selfplay/v2-mcts400-500games.jsonl.gz --items 1200 --k 4 --research 100 --next-search 30 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized_1e5141d.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/realized.log 2>&1
echo AFTERDONE
