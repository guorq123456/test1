#!/bin/bash
# after G_end K=32: the discrimination experiment on Salem's 80 turns (K=32)
while pgrep -f "realized_end.py.*--k 16" > /dev/null; do sleep 60; done
echo K32DONE
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/crosswt2
PYTHONPATH=.:/home/user/test1/analysis/card-value python3 /home/user/test1/analysis/card-value/salem_end.py /home/user/test1/analysis/mirror-regression/positions.json /home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json --k 16 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/salem_end_k32.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/salem_end.log 2>&1
echo SALEMENDDONE
