#!/bin/bash
# after the paired mistakes analysis: pirate-t mirror reruns at 81c4660 (without / with its models), same seed bank
until [ "$(grep -c '个决策' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/salem_mistakes_paired.log)" -ge 27 ]; do sleep 30; done
echo START $(date -u +%H:%M)
L=/home/user/test1/analysis/deck-league/league.py
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/pirwt
SVSIM_PHASED=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/phased_nopirate PYTHONPATH=. python3 $L --decks pirate-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_81c4660_pirmirror_nomodel.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/pirmirror_nomodel.log 2>&1
echo PIRMIRROR nomodel done $(date -u +%H:%M)
PYTHONPATH=. python3 $L --decks pirate-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_81c4660_pirmirror.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/pirmirror.log 2>&1
echo PIRMIRROR models done $(date -u +%H:%M)
