#!/bin/bash
# pirate-t mirror lethal probes (cheap banding): baseline full, no-model only the 11 games that differ, with-model full
until [ "$(grep -c PIRMIRRORDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cn/r19.log)" -ge 2 ]; do sleep 30; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/pirwt
export PYTHONPATH=.:/home/user/test1/analysis/deck-league
P=/home/user/test1/analysis/deck-league/probe_records.py
D=/home/user/test1/analysis/deck-league
nice -n 10 python3 $P --pair pirate-t/pirate-t --cheap --workers 2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_pir_f631e14.jsonl $D/league_v2s_f631e14.jsonl.gz+$D/league_v2s_f631e14_mirror2.jsonl.gz
echo PROBE pir base done $(date -u +%H:%M)
nice -n 10 python3 $P --pair pirate-t/pirate-t --cheap --workers 2 --only 27:0 27:1 45:0 51:0 51:1 57:0 57:1 86:0 86:1 104:0 104:1 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_pir_81c4660_nomodel_diff.jsonl /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_81c4660_pirmirror_nomodel.jsonl.gz
echo PROBE pir nomodel diff done $(date -u +%H:%M)
nice -n 10 python3 $P --pair pirate-t/pirate-t --cheap --workers 2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/probe_pir_81c4660_model.jsonl /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_81c4660_pirmirror.jsonl.gz
echo PROBE pir model done $(date -u +%H:%M)
