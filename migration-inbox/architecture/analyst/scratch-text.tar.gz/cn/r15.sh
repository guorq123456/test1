#!/bin/bash
# replaces r13 (the other three gates go to Salem's machine): elf gate (+fixed if H1) -> elf-t mirror reruns -> ALLGATESDONE
G=/home/user/test1/analysis/tournament-audit/mulligan_gate.py
L=/home/user/test1/analysis/deck-league/league.py
while kill -0 27526 2>/dev/null; do sleep 30; done
echo "elf SPRT $(grep -o 'SPRT 停：H[01]' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_elf_sprt.log) $(date -u +%H:%M)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
export PYTHONPATH=.:/home/user/test1/analysis/tournament-audit
if grep -q 'SPRT 停：H1' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_elf_sprt.log; then
  python3 $G --deck elf-t --way rules --opponents elf-t nemesis-t ramp-t pirate-t --phase fixed --pairs 300 --seed 38500000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_elf_fixed600.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/mull_elf_fixed600.log 2>&1
  echo "elf FIXED done $(date -u +%H:%M)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log
fi
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfwt
SVSIM_PHASED=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/phased_noelf PYTHONPATH=. python3 $L --decks elf-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_3effa47_elfmirror_noelfmodel.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/elfmirror_noelf.log 2>&1
echo "ELFMIRROR noelf done $(date -u +%H:%M)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log
PYTHONPATH=. python3 $L --decks elf-t --pairs 150 --agent v2s --seed 25000000 --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/league_v2s_3effa47_elfmirror.jsonl.gz > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/league/elfmirror.log 2>&1
echo "ELFMIRROR models done $(date -u +%H:%M)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log
echo "ALLGATESDONE $(date -u +%H:%M) (pirate / ramp / nemesis gates moved to Salem's machine)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gate/r11.log
