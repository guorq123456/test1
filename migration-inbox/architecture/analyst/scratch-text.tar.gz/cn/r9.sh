#!/bin/bash
# after the mulligan stability check: hold vs spend, the new cell's extra turn (v2) and the v2s re-check of the 12 held turns
until grep -q STABILITYDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mull/r8.log; do sleep 30; done
echo START $(date -u +%H:%M)
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/mullwt
export PYTHONPATH=.:/home/user/test1/analysis/cross-turn:/home/user/test1/analysis/card-value:/home/user/test1/analysis/mirror-regression
H=/home/user/test1/analysis/cross-turn/hold_vs_spend.py
G=/home/user/test1/analysis/mirror-regression/salem_games.json
P=/home/user/test1/analysis/mirror-regression/evolve_probes.json
python3 $H $G $P --k 16 --workers 4 --cell new --finish v2 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/hold_vs_spend_k32.jsonl
echo NEWROWDONE $(date -u +%H:%M)
python3 $H $G $P --k 16 --workers 4 --cell old --only held --finish v2s --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cv/hold_vs_spend_k32_v2s.jsonl
echo V2SDONE $(date -u +%H:%M)
