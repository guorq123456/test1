import gzip, json, sys
sys.path.insert(0, "/home/user/test1/analysis/deck-league")
import league
games = {}
for l in gzip.open(sys.argv[1], "rt"):
    g = json.loads(l); games[(g["k"], g["seat_a"])] = g
same = diff = 0
for k in [int(x) for x in sys.argv[2].split(",")]:
    a, b = games[(k, 0)]["pair"].split("/")
    for g in league.play_pair((a, b, k, 25000000 + k, "v2s")):
        f = games[(k, g["seat_a"])]
        ok = f["record"].get("actions") == json.loads(json.dumps(g["record"].get("actions"))) and f["winner"] == g["winner"]
        same += ok; diff += not ok
        print(k, g["seat_a"], f["winner"], f["turns"], g["winner"], g["turns"], "OK" if ok else "DIFF", flush=True)
print("same", same, "diff", diff)
