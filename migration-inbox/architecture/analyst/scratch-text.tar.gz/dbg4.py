import sys, random
sys.argv=["x","/home/user/test1/analysis"]
sys.path.insert(0,"/home/user/test1/analysis/salem-top10")
import five
from svsim.core.engine import legal_actions, apply
pos=five.load()
gid,at,rec,st,row=pos[3]
p=st.active
print("opp field:", [(five.name(c.defn)[:8], c.atk, c.life) for c in st.players[1-p].field])
print("my hand:", [five.name(c.defn)[:8] for c in st.players[p].hand])
for a in legal_actions(st):
    d=five.describe(st,a)
    if d.startswith("出 赤流"): print(" ", d)
