import sys, random
sys.argv=["x","/home/user/test1/analysis"]
sys.path.insert(0,"/home/user/test1/analysis/salem-top10")
import five
from svsim.core.actions import PlayCard
from svsim.core.engine import legal_actions
from svsim.core.view import determinize
from svsim.learn.phased import PhasedLearned
pos=five.load()
gid,at,rec,st,row=pos[3]
p=st.active
ev=PhasedLearned()
agent,search=five.finish_agent()
for a in legal_actions(st):
    if isinstance(a,PlayCard) and st.in_hand(p,a.uid).defn.cost==7:
        d=determinize(st,p,random.Random(35000))
        t,line=five.play_out(agent,search,d,a,35700,p)
        print(five.describe(st,a)); print("  line:", " → ".join(line))
        print("  hand at end:", [five.name(c.defn)[:6] for c in t.players[p].hand], "score", round(ev.score(t,p,False),3))
