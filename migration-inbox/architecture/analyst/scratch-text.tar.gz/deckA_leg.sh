#!/bin/bash
# One leg of search A: resumes from state.json, stops itself before the 2-hour cap (state is saved per class).
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_deckA
n=$(ls runs_A_leg*.log 2>/dev/null | wc -l)
log=runs_A_leg$((n+1)).log
timeout 6900 python3 -m svsim.tools.deckbuild --out runs/deckbuild-A --seed 84801000 --anchor-seed 85701000 \
  --seeds-file analysis/deckbuild/seeds-tournament-2026-10-07.txt --random 4 --rounds 10 --workers 4 > $log 2>&1
echo "exit $?" >> $log
tail -5 $log
