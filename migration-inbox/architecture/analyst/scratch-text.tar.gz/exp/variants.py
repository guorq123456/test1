"""Search variants for the experiments (kept outside the repo)."""
from svsim.cards import library as _lib, decks as _decks  # register every card script

import math
from svsim.search.mcts import ISMCTS, _locator, action_key, _rank
from svsim.core.engine import _start_turn, apply, legal_actions


class MaxISMCTS(ISMCTS):
    """ISMCTS whose nodes keep the best leaf value below them (own turn: no adversary)."""

    def _iterate(self, s, me, root):
        node, path, depth = root, [root], 0
        while not s.over and s.active == me and depth < self.max_depth:
            where = _locator(s, me)
            options = {}
            for a in sorted(legal_actions(s), key=lambda a: _rank(s, a)):
                options.setdefault(action_key(s, a, where), a)
            fresh = None
            for k in options:
                child = node.children.get(k)
                if child is None:
                    if fresh is None:
                        fresh = k
                else:
                    child.avail += 1
            if fresh is not None:
                child = node.children[fresh] = type(node)()
                child.avail = 1
                self._step(s, options[fresh])
                path.append(child)
                break
            best, best_ucb = None, -1.0
            for k in options:
                child = node.children[k]
                ucb = child.total + self.c * math.sqrt(math.log(child.avail) / child.visits)
                if ucb > best_ucb:
                    best, best_ucb = k, ucb
            node = node.children[best]
            self._step(s, options[best])
            path.append(node)
            depth += 1
        v = self.value(s, me, False)
        for n in path:
            n.visits += 1
            n.total = v if n.visits == 1 else max(n.total, v)

    def choose(self, state):
        me = state.active
        from svsim.core.view import determinize
        from svsim.search.mcts import Node
        root = Node()
        for _ in range(self.iterations):
            self._iterate(determinize(state, me, self.rng), me, root)
        self.last_root = root
        where = _locator(state, me)
        legal = {action_key(state, a, where): a for a in legal_actions(state)}
        best = max((k for k in legal if k in root.children), key=lambda k: root.children[k].total, default=None)
        return legal[best] if best is not None else next(iter(legal.values()))


class Agent:
    def __init__(self, search):
        self.search = search

    def act(self, state, actions):
        from svsim.agents.greedy_agent import mulligan
        from svsim.core.enums import Phase
        if state.phase != Phase.MAIN:
            return mulligan(state)
        if len(actions) == 1:
            return actions[0]
        return self.search.choose(state)
