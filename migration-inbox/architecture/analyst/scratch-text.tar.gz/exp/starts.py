from svsim.cards import library as _lib, decks as _decks  # register every card script
import pickle, random
def load_starts(path="../exp/positions.pkl"):
    rows = pickle.load(open(path, "rb"))
    starts, seen = [], set()
    for r in rows:
        key = (r["game"], r["turn"])
        if key in seen: continue
        seen.add(key); starts.append(r)
    random.Random(7).shuffle(starts)
    return starts
