#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sv
export PYTHONPATH=.:../exp
python3 ../exp/duel.py mctsmax:200+plan+learned mcts:200+plan+learned mirror 200 1
python3 ../exp/duel.py mctsmax:200+plan mcts:200+plan mirror 200 2
python3 ../exp/duel.py mctsmax:200+plan mcts:200+plan+learned rhino 200 3
python3 ../exp/duel.py mcts:200+plan mcts:200+plan+learned rhino 200 3
python3 ../exp/duel.py turnplan:4000+plan+learned mcts:200+plan+learned mirror 100 4
echo ALLDONE
