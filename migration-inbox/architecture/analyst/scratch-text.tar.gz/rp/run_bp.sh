#!/bin/bash
set -e
R=/home/user/test1/analysis/ramp-pirate/replay.py; G=/home/user/test1/analysis/gates/controls/ramp-t_pirate-t_bprime.jsonl
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rp_999ec27
PYTHONPATH=. python3 $R --rows $G --a "mcts:201+plan+learned+phased=cand-bprime-ramp-t-pirate-t" --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rp/val_bp.jsonl.gz --full --pairs 3
PYTHONPATH=. python3 $R --rows $G --a "mcts:201+plan+learned+phased=cand-bprime-ramp-t-pirate-t" --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/rp/bp.jsonl.gz
echo ALLDONE
