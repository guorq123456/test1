# 运营局面题（从 M4 自动挑，复测过的；README-puzzles.md）

**条件**：对手卡表已知（牌序、手牌未知）。

## 题 1：k = 320

- **对局**：Salem 第 1 批，对局号 1791305215412，动作序号 39；Salem 坐 0 号位。
- **回合**：全局第 13 回合，Salem 自己的第 7 回合；M3 归类 mixed。
- **复测**（default 方向，各 48 局，种子 0 派生）：Salem 的线 0.000，bot 的线 0.000，配对差 **+0.000**（+0.000～+0.000）。M4 里 K = 12 时的差 +0.917。

**当时的局面**（Salem 视角）

```
第 13 回合（你的回合）
对手：主战者 20/20  PP 0/9  进化点 0  超进化点 1  牌组 30  墓场 7  手牌 3
  战场：「约束的《正义》·伊兰翠（Erntz, Governing Justice）」 11/11 威慑 超进化
你：主战者 9/20  PP 10/10  进化点 2  超进化点 2  牌组 27  墓场 8
  战场：（空）
  手牌：「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「日珥咆哮（Roar of Prominence）」 4费；「约束的《正义》·伊兰翠（Erntz, Governing Justice）」 10费 8/8 守护；「古旧天刀·波菈莱（Vorlalai, Eld Blades）」 2费 0/2 毁灭；「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「金银绚烂·璐米欧儿&雅尔贞特（Lumiore & Argente, Shining Wings）」 8费 6/6；「满面笑容的烹饪·琪米卡（Kimika, Cook of Happiness）」 2费 2/1
  对手手牌（Salem 当时看不到）：「古旧天刀·波菈莱（Vorlalai, Eld Blades）」 2费 0/2 毁灭；「日珥咆哮（Roar of Prominence）」 4费；「天刀深渊（Depths of the Eld Blades）」 2费
```

**Salem 这回合的打法**

1. 使用「满面笑容的烹饪·琪米卡（Kimika, Cook of Happiness）」，选择 己方手牌中的「古旧天刀·波菈莱（Vorlalai, Eld Blades）」
2. 超进化「古旧天刀·波菈莱（Vorlalai, Eld Blades）」
3. 使用「断头的斩姬·相枛津（Sagatsumatsu, Fair Beheader）」，选择 己方手牌中的「天刀深渊（Depths of the Eld Blades）」
4. 使用「赤流（Spilling Red）」，选择 己方手牌中的「天刀深渊（Depths of the Eld Blades）」、敌方场上的「约束的《正义》·伊兰翠（Erntz, Governing Justice）」
5. 「断头的斩姬·相枛津（Sagatsumatsu, Fair Beheader）」攻击敌方主战者
6. 结束回合

**bot（`mcts:100+plan+learned+phased`，第 0 步的计划）这回合的打法**

1. 使用「约束的《正义》·伊兰翠（Erntz, Governing Justice）」
2. 结束回合

**Salem 的线打完以后**（ended；Salem 视角，对手要行动）

```
第 14 回合（对手的回合）
对手：主战者 13/20  PP 10/10  进化点 0  超进化点 1  牌组 29  墓场 8  手牌 4
  战场：（空）
你：主战者 12/20  PP 0/10  进化点 2  超进化点 1  牌组 26  墓场 12
  战场：「满面笑容的烹饪·琪米卡（Kimika, Cook of Happiness）」 2/1；「古旧天刀·波菈莱（Vorlalai, Eld Blades）」 3/5 毁灭 超进化；「断头的斩姬·相枛津（Sagatsumatsu, Fair Beheader）」 5/4 疾驰、毁灭、灵气
  手牌：「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「日珥咆哮（Roar of Prominence）」 4费；「约束的《正义》·伊兰翠（Erntz, Governing Justice）」 10费 8/8 守护；「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「金银绚烂·璐米欧儿&雅尔贞特（Lumiore & Argente, Shining Wings）」 8费 6/6；「天刀深渊（Depths of the Eld Blades）」 2费；「赤流（Spilling Red）」 1费
```

**bot 的线打完以后**（ended；Salem 视角，对手要行动）

```
第 14 回合（对手的回合）
对手：主战者 20/20  PP 10/10  进化点 0  超进化点 1  牌组 29  墓场 7  手牌 4
  战场：「约束的《正义》·伊兰翠（Erntz, Governing Justice）」 11/3（上限 11） 威慑 超进化 可攻击
你：主战者 17/20  PP 0/10  进化点 2  超进化点 2  牌组 27  墓场 8
  战场：「约束的《正义》·伊兰翠（Erntz, Governing Justice）」 8/8 守护
  手牌：「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「日珥咆哮（Roar of Prominence）」 4费；「古旧天刀·波菈莱（Vorlalai, Eld Blades）」 2费 0/2 毁灭；「焦灰的安纳提玛·班德奈特（Burnite, Anathema of Ash）」 9费 9/9；「金银绚烂·璐米欧儿&雅尔贞特（Lumiore & Argente, Shining Wings）」 8费 6/6；「满面笑容的烹饪·琪米卡（Kimika, Cook of Happiness）」 2费 2/1
```

