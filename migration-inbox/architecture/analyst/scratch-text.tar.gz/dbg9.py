import sys, json
sys.argv=["x","/home/user/test1/analysis"]
sys.path.insert(0,"/home/user/test1/analysis/salem-top10")
import five
from svsim.core.actions import from_dict
from svsim.core.engine import apply, legal_actions
from svsim.tools import records
recs=json.load(open("/home/user/test1/analysis/mirror-regression/salem_games.json",encoding="utf-8"))["records"]
rec=recs["1791384258804"]
st=records.start(rec)
print("first", st.first, "names", rec.get("names"))
for k,a in enumerate(rec["actions"][:16]):
    act=from_dict(a)
    print(k, "active", st.active, "turn", st.turn, "own", st.players[st.active].turns_taken, five.describe(st, act) if hasattr(act,'__class__') else a)
    apply(st, act)
