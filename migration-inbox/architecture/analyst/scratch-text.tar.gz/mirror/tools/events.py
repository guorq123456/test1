"""Turn the mirror games into a flat event list with full state context."""
import json, glob
from svsim.cards import library, decks
from svsim.tools import records
from svsim.core.actions import from_dict
from svsim.core.engine import apply, play_form
from svsim.core.state import leader_uid

ZH = {}
def zh(defn):
    return getattr(defn, 'name_zh', '') or defn.name

def mirror_files():
    out = []
    for f in sorted(glob.glob('../mirror/games/17913*.json')):
        rec = json.load(open(f))['record']
        if rec['names'] == ['ramp', 'ramp']:
            out.append(f)
    return out

def events(path):
    rec = json.load(open(path))['record']
    st = records.start(rec)
    ev = []
    for a in map(from_dict, rec['actions']):
        k = type(a).__name__
        who = st.active
        p, o = st.players[who], st.players[1 - who]
        own = p.turns_taken
        base = dict(game=path.split('/')[-1][:13], who=who, own=own, pp=p.pp, max_pp=p.max_pp,
                    hand=len(p.hand), hp=p.leader_hp, opp_hp=o.leader_hp,
                    opp_followers=[(zh(c.defn), c.atk, c.life) for c in o.followers],
                    my_followers=[(zh(c.defn), c.atk, c.life) for c in p.followers], ep=p.ep, sep=p.sep)
        if k == 'PlayCard':
            c = st.in_hand(who, a.uid)
            form = play_form(p, c)
            hand_t = [zh(x.defn) for x in p.hand if x.uid in a.targets]
            field_t = [st.on_field(t) for t in a.targets]
            field_t = [(zh(x.defn), x.atk, x.life) for x in field_t if x is not None]
            ev.append(dict(base, kind='play', card=zh(c.defn), cost=form.paid, enhanced=form.enhanced,
                           alt=bool(form.alt), discards=hand_t, targets=field_t, modes=a.modes))
        elif k == 'Evolve':
            c = st.on_field(a.uid)
            hand_t = [zh(x.defn) for x in p.hand if x.uid in a.targets]
            ev.append(dict(base, kind='se' if a.super_ else 'evo', card=zh(c.defn), discards=hand_t, modes=a.modes))
        elif k == 'Attack':
            c = st.on_field(a.attacker)
            t = 'FACE' if a.target == leader_uid(1 - who) else st.on_field(a.target)
            ev.append(dict(base, kind='attack', card=zh(c.defn), atk=c.atk,
                           target=t if t == 'FACE' else (zh(t.defn), t.atk, t.life)))
        elif k == 'UseBonusPP':
            ev.append(dict(base, kind='bonus'))
        elif k == 'EndTurn':
            ev.append(dict(base, kind='end', unspent=p.pp))
        elif k == 'Mulligan':
            ev.append(dict(base, kind='mull', kept=[zh(x.defn) for i, x in enumerate(p.hand) if i not in a.indices],
                           back=[zh(x.defn) for i, x in enumerate(p.hand) if i in a.indices]))
        apply(st, a)
        if st.over:
            break
    return rec, st, ev
