import json, sys, re, collections, glob
from svsim.cards import library, decks
from svsim.ui.session import Session
files = sorted(glob.glob('../mirror/games/17913*.json'))[:5]
files = [f for f in files if json.load(open(f))['record']['names']==['ramp','ramp']]
S = collections.defaultdict(lambda: collections.defaultdict(list))
for f in files:
    rec = json.load(open(f))['record']
    s = Session(); s.resume(rec)
    g = f.split('/')[-1][:13]
    turn = 0
    for line in map(str, s.log):
        m = re.match(r'—— 第 (\d+) 回合', line)
        if m: turn = int(m.group(1)); continue
        m = re.match(r'(你|AI)：(.*)', line)
        if not m: continue
        who = '玩家' if m.group(1) == '你' else 'AI'
        t = m.group(2)
        first = rec['first']
        isfirst = (who == '玩家') == (first == 0)
        own = (turn + 1) // 2 if isfirst else turn // 2
        tag = f"{g[-3:]}:T{own}"
        if t.startswith('使用「掌握天空命运的少女·露莉亚」'):
            S[who]['露莉亚'].append(f"{tag}{'激奏' if '爆能' in t else '白板'}")
        for c in ['焦灰的安纳提玛·班德奈特', '约束的《正义》·伊兰翠', '世界的伙伴·佐伊', '《世界》的呈现', '金银绚烂·璐米欧儿&雅尔贞特']:
            if t.startswith(f'使用「{c}」'):
                S[who][c[:6]].append(f"{tag}{'(激奏)' if '激奏' in t else ''}{'(爆能)' if '爆能' in t else ''}")
        m2 = re.match(r'(超进化|进化)「(.+?)」', t)
        if m2: S[who][m2.group(1)].append(f"{tag}{m2.group(2)[:6]}")
        if '己方手牌中的' in t:
            src = re.match(r'(?:使用|超进化|进化)「(.+?)」', t).group(1)[:5]
            for d in re.findall(r'己方手牌中的「(.+?)」', t):
                S[who]['弃牌'].append(f"{tag}{src}→弃{d[:6]}")
        if t.startswith('使用「赤流」'):
            tg = re.findall(r'敌方场上的「(.+?)」', t)
            S[who]['赤流目标'].append(f"{tag}{tg[0][:6] if tg else '-'}")
        if '攻击敌方主战者' in t:
            S[who]['打脸'].append(f"{tag}{re.match(r'「(.+?)」', t).group(1)[:5]}")
for who in ['玩家', 'AI']:
    print(f"===== {who}")
    for k, v in S[who].items():
        print(f"  {k} ({len(v)}): {v}")
