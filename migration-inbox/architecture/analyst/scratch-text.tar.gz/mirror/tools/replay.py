"""Replay the mirror games turn by turn: python3 replay.py GAME_JSON..."""
import json, sys
from svsim.cards import library, decks  # register scripts
from svsim.tools import records
from svsim.core.actions import from_dict
from svsim.core.engine import apply
from svsim.ui.session import Session

def name(c):
    return getattr(c.defn, 'zh', None) or c.defn.name

for path in sys.argv[1:]:
    d = json.load(open(path))
    rec = d.get('record', d)
    s = Session(); s.resume(rec)
    log = [str(x) for x in s.log]
    # replay again with state snapshots per turn
    st = records.start(rec)
    print(f"\n######## {path.split('/')[-1]}  玩家{'先手' if rec['first']==0 else '后手'}  胜者={'玩家' if rec['winner']==0 else 'AI'}")
    # mulligans
    acts = [from_dict(a) for a in rec['actions']]
    i = 0
    while i < len(acts) and type(acts[i]).__name__ == 'Mulligan':
        who = st.active
        h = [name(c) for c in st.players[who].hand]
        back = [h[j] for j in acts[i].indices]
        apply(st, acts[i])
        print(f"换牌 {'玩家' if who==0 else 'AI'}: 起手{h} 换掉{back} → {[name(c) for c in st.players[who].hand]}")
        i += 1
    cur = None
    def header():
        p = st.players[st.active]
        o = st.players[1-st.active]
        return (f"--T{st.turn} {'玩家' if st.active==0 else 'AI  '} 第{p.turns_taken}回合 PP{p.pp}/{p.max_pp} 手{len(p.hand)} 牌库{len(p.deck)} EP{p.ep} SEP{p.sep} | 血 我{p.leader_hp} 对{o.leader_hp}\n"
                f"   手牌: {[name(c)+('('+str(c.cost)+')') for c in p.hand]}\n"
                f"   场: 己{[name(c)+(f' {c.atk}/{c.life}' if hasattr(c,'atk') and c.defn.is_follower else '') for c in p.field]} 敌{[name(c)+(f' {c.atk}/{c.life}' if c.defn.is_follower else '') for c in o.field]}")
    print(header())
    lastlog = len(log)
    s2 = Session(); s2.state = st
    for a in acts[i:]:
        before_turn = (st.turn, st.active)
        p = st.players[st.active]
        pp_before = p.pp
        desc = str(a)
        try:
            from svsim.ui.text import describe
            desc = describe(st, a)
        except Exception as e:
            pass
        apply(st, a)
        print(f"   · {desc}   [PP {pp_before}→{st.players[before_turn[1]].pp}]" if type(a).__name__!='EndTurn' else f"   · 结束回合 (剩PP {pp_before})")
        if st.over:
            print(f"   == 结束 血 玩家{st.players[0].leader_hp} AI{st.players[1].leader_hp}")
            break
        if (st.turn, st.active) != before_turn:
            print(header())
