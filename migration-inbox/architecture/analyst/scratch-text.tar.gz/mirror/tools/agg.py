import collections
from events import *
W = {0: '玩家', 1: 'AI'}
C = {w: collections.Counter() for w in (0, 1)}
L = {w: collections.defaultdict(list) for w in (0, 1)}
games = []
for f in mirror_files():
    rec, st, ev = events(f)
    g = f.split('/')[-1][10:13]
    games.append((g, rec['first'], st.players[0].leader_hp, st.players[1].leader_hp, st.turn))
    erntz_on = {}
    for e in ev:
        w = e['who']; c, l = C[w], L[w]
        tag = f"{g}:{e['own']}"
        if e['kind'] == 'play':
            c['play:' + e['card']] += 1
            for d in e['discards']:
                c['discard:' + d] += 1
            if e['card'] == '赤流':
                t = e['targets'][0] if e['targets'] else None
                l['赤流目标'].append(f"{tag}{t[0]}{t[1]}/{t[2]}" if t else tag)
            if e['card'] == '露莉亚':
                l['露莉亚'].append(f"{tag}{'激奏' if e['enhanced'] else '白板'}")
            if e['card'] in ('佐伊', '《世界》的呈现'):
                l[e['card']].append(f"{tag}{'激奏' if e['enhanced'] else ''}")
            if e['card'].startswith('金银'):
                l['金龙'].append(f"{tag}{'激奏3' if e['alt'] else '本体'}")
            if e['card'].startswith('禁牙'):
                l['诺玛模式'].append(f"{tag}m{e['modes']}敌随从{len(e['opp_followers'])}")
            if e['card'].startswith('约束'):
                l['伊兰翠下场'].append(f"{tag}血{e['hp']}")
        elif e['kind'] in ('evo', 'se'):
            c[e['kind'] + ':' + e['card']] += 1
            if e['card'].startswith('禁牙'):
                l['诺玛模式'].append(f"{tag}进化m{e['modes']}敌随从{len(e['opp_followers'])}")
            if e['card'].startswith('约束'):
                l['伊兰翠下场'].append(f"{tag}{e['kind']}")
            if e['card'].startswith('焦灰'):
                l['班德'].append(f"{tag}{e['kind']}")
        elif e['kind'] == 'attack':
            if e['target'] == 'FACE':
                l['打脸'].append(f"{tag}{e['card'][:3]}{e['atk']}")
            else:
                c['attack_follower'] += 1
        elif e['kind'] == 'bonus':
            l['额外PP'].append(tag)
        elif e['kind'] == 'end':
            c['unspent'] += e['unspent']; c['turns'] += 1
            if e['own'] >= 6:
                c['late_turns'] += 1; c['late_hand'] += e['hand']
for g in games: print('game', g)
for w in (0, 1):
    print(f"\n===== {W[w]}")
    for k, v in sorted(C[w].items()):
        print(f"  {k}: {v}")
    for k, v in L[w].items():
        print(f"  [{k}] ({len(v)}) {v}")
