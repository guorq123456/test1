import json, sys
from collections import Counter
rows=[json.loads(l) for l in open(sys.argv[1])]
spec=sys.argv[2]
def ks(k):
    if k is None: return "WON"
    ev = ",".join(f"{a}:{b[:4]}" for a,b in k["evolved"]) or "-"
    key = "".join(f"{n[:2]}{c}" for n,c in k["key"].items() if c)
    return f"pp{k['pp_left']}/{k['max_pp']} play{k['playable']}{k['playable_names'] and [n[:4] for n in k['playable_names']]} bonus={k['bonus']} evo={ev} ep{k['ep']}s{k['sep']} key[{key}]"
for r in rows:
    s=r["salem"]; bots=r["bots"][spec]
    sk=s["kept"]
    flags=[]
    for b in bots:
        bk=b["kept"]
        if sk is None or bk is None:
            if (sk is None) != (bk is None): flags.append("won-diff")
            continue
        if sk["bonus"]!=bk["bonus"]: flags.append("bonus")
        if sk["playable"]>bk["playable"]: flags.append("held")
        if sk["pp_left"]>bk["pp_left"]: flags.append("pp")
        if [e[0] for e in sk["evolved"]]!=[e[0] for e in bk["evolved"]] or [e[1] for e in sk["evolved"]]!=[e[1] for e in bk["evolved"]]: flags.append("evo")
        if any(sk["key"][k]>bk["key"][k] for k in sk["key"]): flags.append("key")
    c=Counter(flags)
    if not c: continue
    print(f"== {r['game']} at{r['at']} own{r['own_turn']} {'先' if r['first'] else '后'} hp{r['context']['hp']}-{r['context']['opp_hp']} pp{r['context']['pp']} ep{r['context']['ep']}s{r['context']['sep']} bonus{r['context']['bonus']}  flags {dict(c)}")
    print("   hand:", [h[:6] for h in r['context']['hand']], "board:", r['context']['board'], "opp:", r['context']['opp_board'])
    print("   SALEM:", " | ".join(s["moves"]), "=>", ks(sk))
    for b in bots:
        print(f"   bot{b['seed']}:", " | ".join(b["moves"]), "=>", ks(b["kept"]))
