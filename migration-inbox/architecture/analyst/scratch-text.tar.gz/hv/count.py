import json, sys, time, random
sys.path.insert(0, '/home/user/test1/analysis/card-value')
from svsim.cards import library, decks  # noqa
from svsim.core.actions import PlayCard, UseBonusPP, EndTurn, from_dict
from svsim.core.engine import apply, legal_actions
from svsim.tools import records
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
T = json.load(open('/home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json'))
turns = sorted({(x['game'], x['at']) for x in T})
line_keep = {(x['game'], x['at'], int(x['restriction'].split(':')[1])) for x in T if x['restriction'].startswith('keep:')}
def state_at(rec, at):
    st = records.start(rec)
    for a in rec['actions'][:at]:
        apply(st, from_dict(a))
    return st
def salem_used(rec, at):
    st = state_at(rec, at); me = st.active; used = set()
    for a in rec['actions'][at:]:
        if st.over or st.active != me: break
        act = from_dict(a)
        if isinstance(act, PlayCard):
            c = st.in_hand(me, act.uid)
            if c: used.add(c.defn.card_id)
        before = {c.uid: c.defn.card_id for c in st.players[me].hand}
        apply(st, act)
        after = {c.uid for c in st.players[me].hand} | {c.uid for c in st.players[me].field}
        # discards: cards gone from hand that are not on field (played cards counted above)
        for uid, cid in before.items():
            if uid not in after and not (isinstance(act, PlayCard) and act.uid == uid):
                used.add(cid)
    won = st.over and st.winner == me
    return used, won
def playable(st):
    me = st.active
    ids = {st.in_hand(me, a.uid).defn.card_id for a in legal_actions(st) if isinstance(a, PlayCard) and st.in_hand(me, a.uid)}
    bonus = set()
    if any(isinstance(a, UseBonusPP) for a in legal_actions(st)):
        s2 = st.clone(); apply(s2, UseBonusPP())
        bonus = {s2.in_hand(me, a.uid).defn.card_id for a in legal_actions(s2) if isinstance(a, PlayCard) and s2.in_hand(me, a.uid)} - ids
    return ids, bonus
rows = []
for g, at in turns:
    rec = G[g]; st = state_at(rec, at)
    used, won = salem_used(rec, at)
    if won: continue
    ids, bonus = playable(st)
    hand = {c.defn.card_id for c in st.players[st.active].hand}
    rows.append((g, at, len(hand), len(ids), len(bonus), sum(1 for c in ids | bonus if c in used), sum(1 for c in ids | bonus if (g, at, c) in line_keep)))
n = len(rows)
print('turns kept', n, 'of', len(turns))
print('distinct hand cards', sum(r[2] for r in rows), 'playable at start', sum(r[3] for r in rows), 'only after bonus PP', sum(r[4] for r in rows))
print('items (playable incl bonus)', sum(r[3]+r[4] for r in rows), 'Salem used', sum(r[5] for r in rows), 'teacher line items among them', sum(r[6] for r in rows))
print('per turn items: min/median/max', min(r[3]+r[4] for r in rows), sorted(r[3]+r[4] for r in rows)[n//2], max(r[3]+r[4] for r in rows))
print('turns with >=1 kept and >=1 used item:', sum(1 for r in rows if 0 < r[5] < r[3]+r[4]))
