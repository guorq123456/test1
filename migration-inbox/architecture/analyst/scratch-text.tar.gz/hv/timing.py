import json, sys, time, random
sys.path.insert(0, '/home/user/test1/analysis/card-value')
from svsim.cards import library, decks  # noqa
from svsim.core.actions import from_dict
from svsim.core.engine import apply
from svsim.core.view import determinize
from svsim.tools import records
import realized as R
from realized_end import play_out
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
T = json.load(open('/home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json'))
turns = sorted({(x['game'], x['at'], x['own_turn']) for x in T})
rng = random.Random(1); pick = rng.sample(turns, 6)
spec = sys.argv[1]
R.V2 = spec
tot = n = 0
for g, at, ot in pick:
    st = records.start(G[g])
    for a in G[g]['actions'][:at]:
        apply(st, from_dict(a))
    me = st.active
    base = determinize(st, me, random.Random(7))
    t = time.time(); play_out(base, me, None, 123); dt = time.time() - t
    tot += dt; n += 1
    print(f'turn {ot}: {dt:.1f}s', flush=True)
print(f'{spec}: mean {tot/n:.1f}s per game')
