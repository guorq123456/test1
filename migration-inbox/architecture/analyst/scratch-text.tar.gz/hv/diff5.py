import json, sys
sys.path.insert(0, '/home/user/test1/analysis/card-value')
import salem_discrim as D
import teacher_eval as TE
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
first10 = sorted(json.load(open('/home/user/test1/analysis/card-value/salem_games_10.json'))['records'])
TE.GAMES.update(G)
T = json.load(open('/home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json'))
t10 = {(x['game'], x['at']) for x in T}
for g in first10:
    for at, turn, after in TE.salem_turns(g):
        if (g, at) in t10: continue
        u, w = D.used_this_turn(G[g], at)
        st = D.state_at(G[g], at); now, later = D.playable(st)
        print(g, at, 'own turn', st.players[st.active].turns_taken, 'won', w, 'items', len(now | later), 'pp', st.players[st.active].pp)
