import json, random, sys
sys.path.insert(0, '/home/user/test1/analysis/card-value')
import salem_discrim as D
import realized as R
from svsim.core.engine import apply, legal_actions
from svsim.core.actions import PlayCard, EndTurn, UseBonusPP
from svsim.core.view import determinize
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
D.GAMES.update(G)
rows = [json.loads(l) for l in open('/home/user/test1/analysis/card-value/discrim/g_end.jsonl')]
want = sys.argv[1:]
for it in rows:
    if str(it['n']) not in want: continue
    st = D.state_at(G[it['game']], it['at']); me = st.active
    base = determinize(st, me, random.Random(D.BANK + 100*it['n']))
    veto = D.uses_card(it['card'], me)
    veto.uids = {c.uid for c in base.players[me].hand if c.defn.card_id == it['card']}
    s = base.clone(); p = s.players[me]
    print(f"== n={it['n']} {it['name']} label={it['label']} pp={p.pp}/{p.max_pp} bonus={p.bonus_ready} field={len(p.field)} uids={veto.uids}")
    print('   hand:', [(c.defn.name, c.cost, c.uid) for c in p.hand])
    leg = legal_actions(s)
    pcs = [a for a in leg if isinstance(a, PlayCard) and s.in_hand(me, a.uid) and s.in_hand(me, a.uid).defn.card_id == it['card']]
    print('   legal plays of c:', pcs[:4])
    print('   vetoed now:', [type(a).__name__ for a in leg if veto(s, a)][:10], 'of', len(leg))
    mine = R.agent_with_veto(D.V2, 10*(D.BANK + 100*it['n']), veto)
    steps = 0
    while not s.over and s.active == me and steps < 30:
        legal = legal_actions(s)
        allowed = [a for a in legal if not veto(s, a)]
        a = mine.act(s, legal)
        desc = type(a).__name__ + (' ' + s.in_hand(me, a.uid).defn.name if isinstance(a, PlayCard) and s.in_hand(me, a.uid) else '')
        print(f'   step {steps}: pp={s.players[me].pp} allowed {len(allowed)}/{len(legal)} -> {desc}')
        apply(s, a); steps += 1
    print('   c left hand:', not veto.uids <= {c.uid for c in s.players[me].hand})
