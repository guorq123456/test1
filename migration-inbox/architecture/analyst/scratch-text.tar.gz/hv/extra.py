import json
from svsim.cards import library, decks  # noqa
from svsim.core.actions import PlayCard, UseBonusPP, from_dict
from svsim.core.engine import apply, legal_actions
from svsim.tools import records
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
for g, at in (("1791317238047", 53), ("1791304981889", 35)):
    st = records.start(G[g])
    for a in G[g]['actions'][:at]:
        apply(st, from_dict(a))
    me = st.active; p = st.players[me]
    print(g, at, 'active', me, 'pp', p.pp, '/', p.max_pp, 'bonus', p.bonus_ready, 'turn', p.turns_taken, 'hp', p.leader_hp, st.players[1-me].leader_hp)
    leg = {st.in_hand(me, a.uid).defn.card_id for a in legal_actions(st) if isinstance(a, PlayCard) and st.in_hand(me, a.uid)}
    for c in p.hand:
        print('   ', c.defn.card_id, c.defn.name, c.cost, 'legal' if c.defn.card_id in leg else '')
