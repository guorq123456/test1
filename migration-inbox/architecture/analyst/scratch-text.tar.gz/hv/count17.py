import json, sys
sys.path.insert(0, '/home/user/test1/analysis/card-value')
import salem_discrim as D
import teacher_eval as TE
G = json.load(open('/home/user/test1/analysis/mirror-regression/salem_games.json'))['records']
first10 = set(json.load(open('/home/user/test1/analysis/card-value/salem_games_10.json'))['records'])
ids = sorted(g for g in G if g not in first10)
TE.GAMES.update(G)
turns = []
for g in ids:
    for at, turn, after in TE.salem_turns(g):
        turns.append((g, at))
# check first-10 turn enumeration matches teacher rows
T = json.load(open('/home/user/test1/analysis/card-value/teacher_rows_1e5141d_n30.json'))
t10 = sorted({(x['game'], x['at']) for x in T})
chk = sorted((g, at) for g in sorted(first10) for at, _, _ in TE.salem_turns(g))
print('first10 enumeration matches teacher rows:', chk == t10, len(chk), len(t10))
n_items = n_turns = won = kept = used = bonus = 0
per = []
for g, at in turns:
    u, w = D.used_this_turn(G[g], at)
    if w: won += 1; continue
    st = D.state_at(G[g], at)
    now, later = D.playable(st)
    k = len(now | later)
    if k: n_turns += 1
    n_items += k; bonus += len(later)
    used += sum(1 for c in now | later if c in u); kept += sum(1 for c in now | later if c not in u)
    per.append(k)
print('17 games:', len(ids), 'turns', len(turns), 'winning turns dropped', won, 'turns with items', n_turns, 'items', n_items, 'kept', kept, 'used', used, 'bonus-only', bonus)
