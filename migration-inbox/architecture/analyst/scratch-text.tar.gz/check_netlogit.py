import gzip, json, sys
import numpy as np
from svsim.cards import decks
from svsim.core.actions import EndTurn, from_dict
from svsim.core.engine import apply, new_game
from svsim.search.evaluate import after_end_of_turn
from svsim.ui.session import DECKS
from svsim.learn.setnet import load_cached
net = load_cached("analysis/scaling/models/net-10000.npz")
rec, npz, ngames = sys.argv[1], sys.argv[2], int(sys.argv[3])
d = np.load(npz)
s0 = int(rec.split("rec-")[1].split(".")[0])
lines = [l for l in gzip.open(rec, "rt") if l.strip()][:ngames]
mine = []
for line in lines:
    g = json.loads(line)
    st = new_game(decks.build(DECKS["ramp-t"][1]), decks.build(DECKS["ramp-t"][1]), seed=g["seed"])
    for data in g["actions"]:
        if st.over: break
        act = from_dict(data)
        if isinstance(act, EndTurn):
            me = st.active
            end = after_end_of_turn(st.clone())
            if not end.over:
                y = 1.0 if g["winner"] == me else 0.0
                mine.append((g["g"], end.turn, me, y, net.logit(end, me)))
        apply(st, act)
sel = d["seed"] == s0
theirs = {(int(g), int(t)): (int(p), float(r), float(x)) for g, t, p, r, x in zip(d["g"][sel], d["turn"][sel], d["player"][sel], d["result"][sel], d["net_logit"][sel])}
n = bad = 0; maxd = 0
for g, t, me, y, x in mine:
    o = theirs.get((g, t))
    n += 1
    if o is None or o[0] != me or o[1] != y: bad += 1; continue
    maxd = max(maxd, abs(o[2] - x))
cnt = sum(1 for k in theirs if k[0] < ngames)
print(f"mine {n} positions, theirs {cnt} for the same games, key/label mismatches {bad}, max |logit diff| {maxd:.2e}")
