import json, sys
sys.path.insert(0, "/home/user/test1/analysis/tournament-audit")
import mulligan_gate as mg
rows = {json.loads(l)["k"]: json.loads(l) for l in open(sys.argv[1]) if l.strip()}
ks = [int(x) for x in sys.argv[2].split(",")]
same = diff = 0
for k in ks:
    r = rows[k]
    for seat in (0, 1):
        for way, w in (("R", "rules"), ("D", "default")):
            out = mg.play(r["seed"], "elf-t", r["opp"], seat, w, mg.V2S, r.get("opp_way", "own"))
            exp = r[f"seat{seat}"][way]
            ok = out["points"] == exp["points"] and out["turns"] == exp["turns"]
            same += ok; diff += not ok
            print(k, seat, way, "file", exp["points"], exp["turns"], "replay", out["points"], out["turns"], "OK" if ok else "DIFF", flush=True)
print("same", same, "diff", diff)
