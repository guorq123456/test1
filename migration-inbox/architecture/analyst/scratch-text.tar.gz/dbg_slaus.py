import sys
sys.path[:0] = ['.', 'tests']
from svsim.cards import demo, portal as P
from svsim.core import effects as E
from svsim.core.actions import EndTurn
from svsim.core.engine import apply
from helpers import start, put
for seed in range(6):
    state = start(first=0, seed=seed)
    p, opp = state.players
    crest = E.add_to_leader_area(state, 1, P.SLAUS_CREST)
    log = []
    for i in range(3):
        apply(state, EndTurn())   # opp turn starts
        log.append((crest.countdown, list(crest.counters['wheel']), [ (c.uid, c.cost) for c in opp.hand], crest.fate))
        apply(state, EndTurn())
    print(seed, log)
