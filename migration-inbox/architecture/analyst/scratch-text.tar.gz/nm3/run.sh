#!/bin/bash
# NM3 v2skx self-play (elf-t vs nemesis-t; README 8a1bf95). Order: training k 0-4, holdout h 0-4, then training k 5-9
# (the builder's share unless it is still free). A seed in $S/nm3/SKIP is not played here (another line has it);
# one shard per call; stops before the next shard when $S/nm3/PAUSE exists; resumes a shard from its part file.
# Code eec27ea (svsim/ = 0ccb583). Starts after the NM2 gates; when done, resumes the NM1 gen-2 holdout.
until grep -qE 'DONE|FAILED' /home/user/test1/analysis/gates/scaling/nm2/gate/run.log; do sleep 30; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm2
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm2
for job in "79100000 0" "79100000 1" "79100000 2" "79100000 3" "79100000 4" "79200000 0" "79200000 1" "79200000 2" "79200000 3" "79200000 4" "79100000 5" "79100000 6" "79100000 7" "79100000 8" "79100000 9"; do
  set -- $job
  seed=$(($1 + 2*$2))
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/rec/rec-$seed.jsonl.gz ] && continue
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/PAUSE ]; then echo "paused before $seed"; exit 0; fi
  if grep -qx "$seed" /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/SKIP 2>/dev/null; then echo "skip $seed (another line)"; continue; fi
  python3 -m svsim.learn.scaledata play --deck elf-t --opponent nemesis-t --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $seed at $(date -u +%H:%M:%S)"
done
echo DONE
if [ ! -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/HOLD ]; then rm -f /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/PAUSE; echo "=== resumed after NM3 data at $(date -u +%H:%M:%S)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run.log; nohup /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run2.sh >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run.log 2>&1 & fi
