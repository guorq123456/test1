#!/bin/bash
# NM1 generation-2 self-play (README edaf773): both sides the NM1 bot (cb81fd4 specs, the gates' N: ramp-t 94, elf-t 95).
# Training 78300000 + 2k (k 0-9), then holdout 78400000 + 2h (h 0-4). Code 0ccb583 (--opponent-spec; models as cb81fd4).
# Waits for the NM2 holdout run to finish; one shard per call; stops before the next shard when $S/g2/PAUSE exists.
until grep -qE 'DONE|FAILED|paused' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2/run.log; do sleep 30; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_g2
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_g2
RAMP="mcts:94+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm1f-ramp-elf.npz+netmid+puct=analysis/scaling/models/prior-nm1-ramp-t.npz:2:1"
ELF="mcts:95+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm1f-ramp-elf.npz+netmid+puct=analysis/scaling/models/prior-nm1-elf-t.npz:2:1"
for job in "78300000 0" "78300000 1" "78300000 2" "78300000 3" "78300000 4" "78300000 5" "78300000 6" "78300000 7" "78300000 8" "78300000 9" "78400000 0" "78400000 1" "78400000 2" "78400000 3" "78400000 4"; do
  set -- $job
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/PAUSE ]; then echo "paused before $1 + 2*$2"; exit 0; fi
  python3 -m svsim.learn.scaledata play --deck ramp-t --opponent elf-t --spec "$RAMP" --opponent-spec "$ELF" --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $(($1 + 2*$2)) at $(date -u +%H:%M:%S)"
done
echo DONE
