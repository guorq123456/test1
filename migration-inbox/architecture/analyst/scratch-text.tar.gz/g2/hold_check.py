import gzip, json, sys
from svsim.learn.scaledata import _play, _stable
P = "plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"; M = "analysis/scaling/models"
RAMP = f"mcts:94+{P}+setnet={M}/net-nm1f-ramp-elf.npz+netmid+puct={M}/prior-nm1-ramp-t.npz:2:1"
ELF = f"mcts:95+{P}+setnet={M}/net-nm1f-ramp-elf.npz+netmid+puct={M}/prior-nm1-elf-t.npz:2:1"
D = sys.argv[1]
for seed, gs in ((78400000, (3, 20, 500, 999)), (78400002, (3, 60, 500, 999))):
    want = {r["g"]: _stable(r) for r in map(json.loads, gzip.open(f"{D}/rec-{seed}.jsonl.gz", "rt")) if r["g"] in gs}
    for g in gs:
        rec = _play((seed, g, "ramp-t", "elf-t", RAMP, ELF))[1]
        print(seed, g, "same" if _stable(json.loads(json.dumps(rec))) == want[g] else "DIFFERENT", flush=True)
