import gzip, json, sys
from svsim.learn.scaledata import _play, _stable
P = "plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"; M = "analysis/scaling/models"
RAMP = f"mcts:94+{P}+setnet={M}/net-nm1f-ramp-elf.npz+netmid+puct={M}/prior-nm1-ramp-t.npz:2:1"
ELF = f"mcts:95+{P}+setnet={M}/net-nm1f-ramp-elf.npz+netmid+puct={M}/prior-nm1-elf-t.npz:2:1"
gs = (3, 500, 894, 895, 950, 999)
want = {r["g"]: _stable(r) for r in map(json.loads, gzip.open(sys.argv[1], "rt")) if r["g"] in gs}
for g in gs:
    rec = _play((78300006, g, "ramp-t", "elf-t", RAMP, ELF))[1]
    print(g, "before" if g < 895 or g in (0,) else "after", "same" if _stable(json.loads(json.dumps(rec))) == want[g] else "DIFFERENT", flush=True)
