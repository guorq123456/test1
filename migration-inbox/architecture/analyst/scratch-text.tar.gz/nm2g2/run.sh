#!/bin/bash
# NM2 generation-2 self-play (README 1d95884 / 47d4360): both sides the NM2 bot (eec27ea specs; ramp-t N 94, nemesis-t
# N 75, the install N after the gate's in-gate time). Training 80100000 + 2k (k 0-9), then holdout 80200000 + 2h.
# A seed in $S/nm2g2/SKIP is not played here; stops before the next shard when $S/nm2g2/PAUSE exists. Code eec27ea.
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm2
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm2
RAMP="mcts:94+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm2f-ramp-nem.npz+netmid+puct=analysis/scaling/models/prior-nm2-ramp-t.npz:2:1"
NEM="mcts:75+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm2f-ramp-nem.npz+netmid+puct=analysis/scaling/models/prior-nm2-nemesis-t.npz:2:1"
for job in "80100000 0" "80100000 1" "80100000 2" "80100000 3" "80100000 4" "80100000 5" "80100000 6" "80100000 7" "80100000 8" "80100000 9" "80200000 0" "80200000 1" "80200000 2" "80200000 3" "80200000 4"; do
  set -- $job
  seed=$(($1 + 2*$2))
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2g2/rec/rec-$seed.jsonl.gz ] && continue
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2g2/PAUSE ]; then echo "paused before $seed"; exit 0; fi
  if grep -qx "$seed" /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2g2/SKIP 2>/dev/null; then echo "skip $seed (another line)"; continue; fi
  python3 -m svsim.learn.scaledata play --deck ramp-t --opponent nemesis-t --spec "$RAMP" --opponent-spec "$NEM" --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2g2/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $seed at $(date -u +%H:%M:%S)"
done
echo DONE
