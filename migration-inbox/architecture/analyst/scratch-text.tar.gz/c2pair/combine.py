import re, sys, glob, os
D = os.path.dirname(os.path.abspath(__file__))
order = ["elf-t-elf-t", "elf-t-nemesis-t", "elf-t-ramp-t", "nemesis-t-elf-t", "nemesis-t-ramp-t",
         "pirate-t-elf-t", "pirate-t-pirate-t", "ramp-t-elf-t", "ramp-t-nemesis-t", "ramp-t-pirate-t"]
print("| 组合 | 时刻 | 局面数 | 现装* | B′ | C2 | C2 − B′（95%，按局重抽） | 现装* − B′ |")
print("|---|---|---|---|---|---|---|---|")
for p in order:
    t = open(f"{D}/holdout_{p}.txt", encoding="utf-8").read()
    ll, n = {}, {}
    for m in re.finditer(r"^\| (B′|C2|现装) \| (ended|act) \| (\d+) \| ([0-9.]+) \|", t, re.M):
        ll[(m[1], m[2])] = float(m[4]); n[m[2]] = int(m[3])
    diff = {}
    for m in re.finditer(r"^\| (C2|现装) \| ([^|]+) \| ([^|]+) \|$", t, re.M):
        diff[m[1]] = (m[2].strip(), m[3].strip())
    for j, mo in enumerate(("ended", "act")):
        print(f"| {p if j == 0 else ''} | {mo} | {n[mo]} | {ll[('现装', mo)]:.4f} | {ll[('B′', mo)]:.4f} | {ll[('C2', mo)]:.4f} | "
              f"{diff['C2'][j]} | {diff['现装'][j].split('（')[0]} |")
