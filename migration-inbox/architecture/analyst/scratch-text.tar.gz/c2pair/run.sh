#!/bin/bash
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
D=$S/c2pair; W=$S/wt_build; M=$W/svsim/learn/phased_models
H=/home/user/test1/analysis/refit-200/holdout.py
cd $W
for pm in elf-t-elf-t:elf-t_elf-t elf-t-nemesis-t:nemesis-t_elf-t elf-t-ramp-t:elf-t_ramp-t nemesis-t-elf-t:nemesis-t_elf-t nemesis-t-ramp-t:nemesis-t_ramp-t pirate-t-elf-t:pirate-t_elf-t pirate-t-pirate-t:pirate-t_pirate-t ramp-t-elf-t:elf-t_ramp-t ramp-t-nemesis-t:nemesis-t_ramp-t ramp-t-pirate-t:pirate-t_ramp-t; do
  p=${pm%%:*}; f=${pm##*:}
  echo "### $p ($f)" 
  PYTHONPATH=. python3 $H --games $D/$f.jsonl.gz --every 11 --side $p --workers 4 --boot 2000 \
     "B′=$M/cand-bprime-$p/$p" "C2=$M/cand-c2-hand-$p/$p" "现装=$M/$p" --out $D/rows_$p.jsonl > $D/holdout_$p.txt 2>&1
  echo "done $p $(date -u +%H:%M:%S)"
done
