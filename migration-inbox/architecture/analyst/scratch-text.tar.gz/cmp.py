import json, glob, re, sys
sys.path.insert(0,'onewt')
from svsim.cards.pool import POOL
from svsim.core.enums import Keyword, KEYWORD_NAMES
base='cardtext/'
data={}; tribes={}
for f in glob.glob(base+'set_*_en.json'):
    d=json.load(open(f))['data']
    for k,v in d['card_details'].items(): data[int(k)]=v
    for k,v in (d.get('tribe_names') or {}).items(): tribes[int(k)]=v
dos=json.load(open('audit/dossier.json'))['nemesis-t-a']['cards']
ids=[c['id'] for c in dos]+[90071110,90071120,90071130,90071140,90071150,90071160,90072110,90074140,90074320,90073110,90073120,90073130,90074110]
TYPES={1:'FOLLOWER',2:'AMULET',3:'COUNTDOWN_AMULET',4:'SPELL'}
for i in ids:
    c=data[i]['common']; p=POOL[i]
    txt=c['skill_text']
    # keywords standing alone as static lines
    kws=set()
    for name in KEYWORD_NAMES:
        # static keyword lines: line equals keyword
        for line in re.split(r'\n|<hr>', txt):
            l=re.sub(r'<[^>]+>','',line).strip()
            if l==name: kws.add(name)
    pk={n for n,k in KEYWORD_NAMES.items() if p.keywords & k}
    tr=[tribes.get(t,t) for t in c['tribes'] if t]
    probs=[]
    if (c['cost'],c['atk'],c['life'])!=(p.cost,p.atk,p.life): probs.append(('stats',(c['cost'],c['atk'],c['life']),(p.cost,p.atk,p.life)))
    if TYPES[c['type']]!=p.type.name: probs.append(('type',c['type'],p.type.name))
    if kws!=pk: probs.append(('kw',kws,pk))
    if sorted(tr)!=sorted(p.traits): probs.append(('traits',tr,p.traits))
    if c['class']!=int(p.craft): probs.append(('craft',c['class'],p.craft))
    print(i,p.name,'OK' if not probs else probs)
