import sys, json
sys.path.insert(0, "/home/user/test1/analysis/card-value")
import student_data as SD, teacher_ends as TE
D = sys.argv[1]
games = {r["g"]: r for r in SD._lines(D + "/selfplay.jsonl")}
pos = {p["n"]: p for p in SD._lines(D + "/positions.jsonl")}
TE._init(games, pos)
out = {}
for n, s in [(1660, 0), (493, 1), (2564, 1), (5, 1), (0, 0)]:
    rows = TE._job((n, s))
    d = {}
    for r in rows: d.setdefault(r["r"], [None]*8)[r["j"]] = r
    out[f"{n},{s}"] = {r: round(v[0], 6) for r, v in TE.teacher_values(d).items()}
print(json.dumps(out))
