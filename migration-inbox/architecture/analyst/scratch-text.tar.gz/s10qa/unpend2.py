"""Take card ids out of svsim/cards/pending.py PENDING in place (no reflow; empty lines dropped)."""
import re, sys
ids = [x for x in sys.argv[1:]]
p = 'svsim/cards/pending.py'
s = open(p).read()
m = re.search(r"PENDING = frozenset\(\{\n(.*?)\n\}\)", s, re.S)
body = m.group(1)
for i in ids:
    assert re.search(rf"\b{i}\b", body), i
    body = re.sub(rf"\b{i}, ?", "", body)
lines = [ln.rstrip() for ln in body.split("\n")]
lines = [ln for ln in lines if ln.strip()]
s = s[:m.start(1)] + "\n".join(lines) + s[m.end(1):]
open(p, 'w').write(s)
