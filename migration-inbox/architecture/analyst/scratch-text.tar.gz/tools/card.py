import json, glob, sys, re
base='/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cardtext/'
idx={}
for f in sorted(glob.glob(base+'set_*_*.json')):
    lang=f.rsplit('_',1)[1][:-5]
    d=json.load(open(f))
    for cid,c in d['data']['card_details'].items():
        idx.setdefault(cid,{})[lang]=c
def clean(s): return re.sub(r'<[^>]+>','',s or '')
for cid in sys.argv[1:]:
    c=idx.get(cid)
    if not c: print(cid,'NOT FOUND'); continue
    for lang in ('en','chs'):
        if lang not in c: continue
        com=c[lang]['common']
        print(f"== {cid} [{lang}] {com['name']} cost{com['cost']} {com['atk']}/{com['life']} type{com['type']} token{com['is_token']} tribes{com.get('tribes')} class{com.get('class')}")
        print('  ', clean(com['skill_text']).replace('\n','\n   '))
        ev=c[lang].get('evo') or {}
        if ev.get('skill_text') and ev['skill_text']!=com['skill_text']:
            print('  EVO:', clean(ev['skill_text']).replace('\n','\n   '))
        for q in com.get('questions',[]):
            print('   Q:',q.get('question')); print('   A:',q.get('answer'))
