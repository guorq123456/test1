import sys, importlib.util, functools
sys.path[:0] = ['.', 'tests']
import helpers
spec = importlib.util.spec_from_file_location('t', '/home/user/test1/tests/test_tournament_nemesis_t_a.py')
t = importlib.util.module_from_spec(spec); spec.loader.exec_module(t)
orig = helpers.start
fails = {}
for seed in range(40):
    t.start = functools.partial(lambda s, first=0, seed=0, deck=None, deck1=None: orig(first=first, seed=s, deck=deck, deck1=deck1), seed)
    for name in dir(t):
        if name.startswith('test_'):
            try:
                getattr(t, name)()
            except Exception as e:
                fails.setdefault(name, []).append((seed, repr(e)[:200]))
print(fails or 'all seeds pass')
