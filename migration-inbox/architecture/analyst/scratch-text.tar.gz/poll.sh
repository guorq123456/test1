#!/bin/bash
SP=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
G="git -C /home/user/test1"
snap() { for b in $($G branch -r | grep "origin/local/"); do $G ls-tree -r --name-only $b 2>>$SP/poll.err | sed "s#^#$b:#"; done | sort; }
$G fetch -q origin 2>>$SP/poll.err
snap > $SP/local_snapshot.txt
echo "snapshot $(wc -l < $SP/local_snapshot.txt) lines at $(date -u +%H:%M:%S)" >> $SP/poll.err
while true; do
  sleep 300
  $G fetch -q origin 2>>$SP/poll.err || continue
  snap > $SP/local_now.txt
  [ -s $SP/local_now.txt ] || { echo "empty snap $(date -u +%H:%M:%S)" >> $SP/poll.err; continue; }
  new=$(comm -13 $SP/local_snapshot.txt $SP/local_now.txt | grep -E "local-runs/|tournament-audit/local/|calibration/|mlp-gates/|refit|selfplay-s|evaluator")
  if [ -n "$new" ]; then echo "$new"; for b in $($G branch -r | grep "origin/local/"); do $G log -1 --format="$b %h %ci %s" $b; done; break; fi
done
