#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sv3
export PYTHONPATH=.:../exp3
python3 ../exp3/duel.py turn:3000+plan+learned mcts:200+plan+learned mirror 200 11
python3 ../exp3/duel.py tpc:3000+plan+learned mcts:200+plan+learned mirror 200 11
echo ALLDONE
