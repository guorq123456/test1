import gzip, json, sys
import numpy as np
from svsim.cards import decks
from svsim.core.actions import EndTurn, from_dict
from svsim.core.engine import apply, new_game
from svsim.search.evaluate import after_end_of_turn
from svsim.ui.session import DECKS
from svsim.learn.setnet import load_cached
net = load_cached(sys.argv[1]); d = np.load(sys.argv[2]); rec = sys.argv[3]; ngames = int(sys.argv[4])
s0 = int(rec.split("rec-")[1].split(".")[0])
theirs = {(int(g), int(t)): float(p) for s, g, t, p in zip(d["seed"], d["g"], d["turn"], d["p"]) if int(s) == s0}
n = miss = 0; maxd = 0.0
for line in [l for l in gzip.open(rec, "rt") if l.strip()][:ngames]:
    g = json.loads(line)
    st = new_game(decks.build(DECKS["ramp-t"][1]), decks.build(DECKS["ramp-t"][1]), seed=g["seed"])
    for data in g["actions"]:
        if st.over: break
        act = from_dict(data)
        if isinstance(act, EndTurn):
            me = st.active
            end = after_end_of_turn(st.clone())
            if not end.over:
                p = 1 / (1 + np.exp(-net.logit(end, me)))
                o = theirs.get((g["g"], end.turn))
                if o is None: miss += 1
                else: n += 1; maxd = max(maxd, abs(o - p))
        apply(st, act)
print(f"{n} positions matched, {miss} missing, max |p diff| {maxd:.2e}")
