import sys
sys.path.insert(0, '/home/user/test1/analysis/card-value')
import svsim.learn.features as F
def dummy(state, player):
    p = state.players[player]
    return [sum(min(1.0, (p.max_pp + 1) / max(c.cost, 1)) * (1 + 0.1 * c.cost) for c in p.hand)]
F.EXTRA_FNS["hand_value"] = dummy
F.EXTRAS["hand_value"] = ["hand_value"]
import student_checks
student_checks.main()
