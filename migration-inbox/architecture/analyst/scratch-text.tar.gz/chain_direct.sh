#!/bin/bash
# After the analysis line's NM3 shards (runner prints DONE), run the NM1 gen-2 direct test vs v2skx on the idle
# machine, then resume the gen-2 holdout. Stops if $S/chain.STOP exists.
until grep -qE '^DONE|FAILED' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/run.log; do sleep 60; [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/chain.STOP ] && exit 0; done
grep -q FAILED /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm3/run.log && { echo "NM3 failed; chain stops"; exit 1; }
[ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/chain.STOP ] && exit 0
D=/home/user/test1/analysis/gates/scaling/nm1g2/direct
echo "direct test starts at $(date -u +%H:%M:%S)"
$D/run.sh > $D/run.log 2>&1
cat $D/run.log
grep -q DONE $D/run.log || exit 1
[ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/chain.STOP ] && exit 0
rm -f /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/HOLD /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/PAUSE
echo "=== resumed after the gen-2 direct test at $(date -u +%H:%M:%S)" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run.log
nohup /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run2.sh >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run.log 2>&1 &
echo "g2 holdout resumed"
