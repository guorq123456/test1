import sys, json
sys.path.insert(0, "/home/user/test1/analysis/card-value")
import student_data as SD, teacher_eval as TE, teacher_ends as TEnds
D = sys.argv[1]
games = {r["g"]: r for r in SD._lines(D + "/selfplay.jsonl")}
pos = {p["n"]: p for p in SD._lines(D + "/positions.jsonl")}
TE.GAMES.update({str(k): v for k, v in games.items()})
TEnds._init(games, pos)
for n, s in [(0, 0), (1, 0), (2405, 1), (7588, 0), (5, 1)]:
    p = pos[n]
    gid, at, seed, res = TE.measure((str(p["g"]), p["at"], SD.BANK + 20000 + 2 * n + s, 8, 100, 30, 0))
    rows = TEnds._job((n, s))
    from collections import defaultdict
    g = defaultdict(lambda: [None]*8)
    for r in rows: g[r["r"]][r["j"]] = r
    T = {r: sum(x["value"] - b["value"] for x, b in zip(v, g["line"])) / 8 for r, v in g.items() if r != "line"}
    same = set(T) == set(res) and all(abs(T[k] - res[k]["teacher"]) < 1e-15 for k in T)
    starts = TEnds.Starts(D + "/selfplay.jsonl")
    ok = all(TEnds.turn_end(r, starts) is not None for r in rows)
    print(f"n={n} s={s}: {len(rows)} rows; T identical to teacher_eval.measure on this machine: {same}; every turn end rebuilt with its summary: {ok}")
