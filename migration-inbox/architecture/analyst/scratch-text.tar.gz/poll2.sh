#!/bin/bash
# trigger on any new commit on the local/* branches (a rewritten file under the same name included)
SP=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
G="git -C /home/user/test1"
heads() { for b in $($G branch -r | grep "origin/local/"); do echo "$b $($G rev-parse $b)"; done | sort; }
$G fetch -q origin 2>>$SP/poll.err
heads > $SP/heads_then.txt
echo "heads snapshot at $(date -u +%H:%M:%S)" >> $SP/poll.err
while true; do
  sleep 300
  $G fetch -q origin 2>>$SP/poll.err || continue
  heads > $SP/heads_now.txt
  [ -s $SP/heads_now.txt ] || continue
  if ! cmp -s $SP/heads_then.txt $SP/heads_now.txt; then
    for b in $($G branch -r | grep "origin/local/"); do
      old=$(grep "^$b " $SP/heads_then.txt | cut -d' ' -f2)
      new=$($G rev-parse $b)
      [ "$old" != "$new" ] && $G log --format="$b %h %ci %s" ${old:+$old..}$new | head -10 && $G diff --name-status $old $new 2>/dev/null | head -20
    done
    break
  fi
done
