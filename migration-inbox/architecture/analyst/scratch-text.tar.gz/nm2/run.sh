#!/bin/bash
# NM2 v2skx self-play (ramp-t vs nemesis-t), analysis line's share (README edaf773): holdout 78800000 + 2h (h 0-4).
# One shard per call; stops before the next shard when $S/nm2/PAUSE exists. Code cb81fd4 (svsim/ = 91e88e0).
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm1
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_nm1
for job in "78800000 0" "78800000 1" "78800000 2" "78800000 3" "78800000 4"; do
  set -- $job
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2/PAUSE ]; then echo "paused before $1 + 2*$2"; exit 0; fi
  python3 -m svsim.learn.scaledata play --deck ramp-t --opponent nemesis-t --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm2/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $(($1 + 2*$2)) at $(date -u +%H:%M:%S)"
done
echo DONE
