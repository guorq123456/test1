#!/bin/bash
# NM1 v2skx self-play, analysis line's share (README b51eca4 rules): holdout 78000000 + 2h (h 0-4), then training 77900000 + 2k (k 8, 9).
# One shard per call; stops before the next shard when $S/nm1/PAUSE exists. Code 91e88e0.
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_oph
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_oph
for job in "78000000 0" "78000000 1" "78000000 2" "78000000 3" "78000000 4" "77900000 8" "77900000 9"; do
  set -- $job
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm1/PAUSE ]; then echo "paused before $1 + 2*$2"; exit 0; fi
  python3 -m svsim.learn.scaledata play --deck ramp-t --opponent elf-t --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/nm1/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $(($1 + 2*$2)) at $(date -u +%H:%M:%S)"
done
echo DONE
