"""Take card ids out of svsim/cards/pending.py PENDING, keeping its 8-per-line layout."""
import re, sys
ids = {int(x) for x in sys.argv[1:]}
p = 'svsim/cards/pending.py'
s = open(p).read()
m = re.search(r"PENDING = frozenset\(\{\n(.*?)\n\}\)", s, re.S)
body = m.group(1)
comment = re.findall(r"#.*", body)
nums = [int(x) for x in re.findall(r"\d{8}", re.sub(r"#.*", "", body))]
missing = ids - set(nums)
assert not missing, missing
keep = [n for n in nums if n not in ids]
lines = ["    " + ", ".join(str(n) for n in keep[i:i + 8]) + "," for i in range(0, len(keep), 8)]
new = "PENDING = frozenset({\n" + "\n".join(lines) + ("  " + comment[0] if comment else "") + "\n})"
s = s[:m.start()] + new + s[m.end():]
open(p, 'w').write(s)
print(len(nums), "->", len(keep))
