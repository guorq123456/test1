#!/bin/bash
# NM1 generation-3 self-play (README 1d95884): both sides the gen-2 bot (b9e6f75 specs; ramp-t N 89 per the direct
# test's correction 241f476, elf-t N 95). Training 79700000 + 2k (k 0-9), then holdout 79800000 + 2h (h 0-4).
# A seed in $S/g3/SKIP is not played here; stops before the next shard when $S/g3/PAUSE exists; resumes from part.
# Starts after the gen-2 holdout runner prints DONE. Code b9e6f75.
until grep -qE '^DONE|FAILED' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g2/run.log; do sleep 60; [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g3/PAUSE ] && exit 0; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_g2gate
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_g2gate
RAMP="mcts:89+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm1g2-ramp-elf.npz+netmid+puct=analysis/scaling/models/prior-nm1g2-ramp-t.npz:2:1"
ELF="mcts:95+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-nm1g2-ramp-elf.npz+netmid+puct=analysis/scaling/models/prior-nm1g2-elf-t.npz:2:1"
for job in "79700000 0" "79700000 1" "79700000 2" "79700000 3" "79700000 4" "79700000 5" "79700000 6" "79700000 7" "79700000 8" "79700000 9" "79800000 0" "79800000 1" "79800000 2" "79800000 3" "79800000 4"; do
  set -- $job
  seed=$(($1 + 2*$2))
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g3/rec/rec-$seed.jsonl.gz ] && continue
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g3/PAUSE ]; then echo "paused before $seed"; exit 0; fi
  if grep -qx "$seed" /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g3/SKIP 2>/dev/null; then echo "skip $seed (another line)"; continue; fi
  python3 -m svsim.learn.scaledata play --deck ramp-t --opponent elf-t --spec "$RAMP" --opponent-spec "$ELF" --base $1 --stride 2 --shards $2 $(($2 + 1)) --per-shard 1000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/g3/rec || { echo "FAILED $1 $2"; exit 1; }
  echo "done $seed at $(date -u +%H:%M:%S)"
done
echo DONE
