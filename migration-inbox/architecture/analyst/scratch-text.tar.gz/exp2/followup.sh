#!/bin/bash
until grep -q ALLDONE /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/exp2/arena.log; do sleep 10; done
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/sv2
export PYTHONPATH=.:../exp2
python3 ../exp2/duel.py "mcts:200+plan#rhino" mcts:200+plan rhino 200 3
python3 ../exp2/duel.py "mcts:800+plan#rhino" mcts:200+plan rhino 200 3
echo FOLLOWDONE
