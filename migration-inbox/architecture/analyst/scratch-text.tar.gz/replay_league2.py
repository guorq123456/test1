import gzip, json, sys
sys.path.insert(0, "/home/user/test1/analysis/deck-league")
import league
games = {}
for l in gzip.open(sys.argv[1], "rt"):
    g = json.loads(l); games[(g["pair"], g["k"], g["seat_a"])] = g
same = diff = 0
for (pair, k, seat), f in sorted(games.items()):
    if seat != 0: continue
    a, b = pair.split("/")
    for g in league.play_pair((a, b, k, 25000000 + k, "v2s")):
        f2 = games[(pair, k, g["seat_a"])]
        ok = f2["record"]["actions"] == json.loads(json.dumps(g["record"]["actions"])) and f2["winner"] == g["winner"]
        same += ok; diff += not ok
        print(pair, k, g["seat_a"], "OK" if ok else "DIFF", flush=True)
print("same", same, "diff", diff)
