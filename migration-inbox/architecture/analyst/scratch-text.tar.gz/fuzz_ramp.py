import sys, random, collections
sys.path.insert(0, '.')
from svsim.cards import decks
from svsim.core.engine import new_game, apply, legal_actions
from svsim.core.state import FIELD_LIMIT, HAND_LIMIT
from svsim.core.actions import Mulligan
from svsim.agents.random_agent import RandomAgent

H = "1.4.cJl6.cJl6.cJl6.dhqm.dhqm.drrE.drrE.drrO.drrO.drrO.eE3E.eE3E.eE3E.eEFk.eEFk.eEFk.ecgE.ecgE.ecgE.ecgO.ecgO.ecgO.e-Ls.e-Ls.e-Ls.e_4k.e_4k.e_4k.fDkE.fN08.fN08.fN08.fNIk.fNIk.fNVO.fNVO.fNVO.flvu.flvu.flvu"
deck = decks.from_hash(H)
print(len(deck), collections.Counter(c.name for c in deck))
print(decks.validate(deck))
played = collections.Counter()
for g in range(300):
    st = new_game(deck, deck, seed=g)
    agents = [RandomAgent(g, 0.3), RandomAgent(g + 1000, 0.3)]
    while not st.over:
        acts = legal_actions(st)
        a = agents[st.active].act(st, acts)
        if hasattr(a, 'uid') and type(a).__name__ == 'PlayCard':
            c = st.in_hand(st.active, a.uid)
            played[c.defn.name] += 1
        apply(st, a)
        assert not st.queue
        for p in st.players:
            assert len(p.field) <= FIELD_LIMIT and len(p.hand) <= HAND_LIMIT
            assert all(c.life > 0 for c in p.followers)
            assert p.leader_hp <= p.leader_max_hp
            assert 0 <= p.pp <= 11 and p.max_pp <= 10
print('ok', played.most_common())
