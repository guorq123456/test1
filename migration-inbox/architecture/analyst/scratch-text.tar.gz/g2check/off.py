# Off-unchanged check of --opponent-spec (0ccb583): replay NM1 games (cb81fd4 code made them) with the new code,
# (a) no opponent spec, (b) opponent spec = the same v2skx string; both must equal the committed record.
import gzip, json, sys
from svsim.learn.scaledata import SPEC, _play, _stable
want = {}
for path, seed, gs in ((sys.argv[1], 77900016, (0, 501)), (sys.argv[2], 78000004, (2, 777))):
    for line in gzip.open(path, "rt"):
        r = json.loads(line)
        if r["g"] in gs:
            want[(seed, r["g"])] = _stable(r)
for (seed, g), w in sorted(want.items()):
    a = _stable(json.loads(json.dumps(_play((seed, g, "ramp-t", "elf-t", SPEC))[1])))
    b = _stable(json.loads(json.dumps(_play((seed, g, "ramp-t", "elf-t", SPEC, SPEC))[1])))
    print(seed, g, "off same" if a == w else "OFF DIFFERENT", "| same-spec same" if b == w else "| SAME-SPEC DIFFERENT", flush=True)
