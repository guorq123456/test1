import multiprocessing, sys
multiprocessing.set_start_method("spawn")
from svsim.tools import host
sys.argv = ["host"] + sys.argv[1:]
host.main()
