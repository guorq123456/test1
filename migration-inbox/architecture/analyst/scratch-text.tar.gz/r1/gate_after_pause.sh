#!/bin/bash
until grep -qE 'paused|DONE|FAILED' /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/r1/run_mine.log; do sleep 10; done
while pgrep -f relabel.py > /dev/null; do sleep 5; done
echo "relabel stopped: $(tail -2 /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/r1/run_mine.log | tr '\n' ' ') at $(date -u +%H:%M:%S)"
uptime
bash /home/user/test1/analysis/gates/scaling/mid/mid_elf.sh
echo "gate finished at $(date -u +%H:%M:%S)"
