#!/bin/bash
# R1 relabel, analysis line's shards k = 26..35 (36..39 handed to the builder 13:5x) (README 96c5b24). Stops before the next shard when $S/r1/PAUSE exists.
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_mid
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_mid
for k in $(seq 26 35); do
  if [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/r1/PAUSE ]; then echo "paused before k=$k"; exit 0; fi
  f=/home/user/test1/analysis/scaling/data/gen4x/rec/rec-$((72300000 + 2*k)).jsonl.gz
  python3 /home/user/test1/analysis/gates/scaling/r1/relabel.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/r1/ramp $f --workers 3 || { echo "FAILED k=$k"; exit 1; }
done
echo DONE
