import json, sys, time, random
sys.path.insert(0, "/home/user/test1/analysis/card-value")
import student_data as SD, teacher_eval as TE
from svsim.agents.crossturn_agent import CrossTurnAgent, principal_line, restrictions, NONE
from svsim.tools.arena import make_agent
D = sys.argv[1]
games = {str(r["g"]): r for r in SD._lines(D + "/selfplay.jsonl")}
pos = {p["n"]: p for p in SD._lines(D + "/positions.jsonl")}
trows = {(r["n"], r["s"]): r for r in SD._lines(D + "/teacher.jsonl")}
TE.GAMES.update(games)

class Ends(CrossTurnAgent):
    """The teacher up to the end of each candidate's own turn: no opponent turn, no play-out."""
    def _their_turn(self, s, me):
        self.ends.append(s.clone())
    def _value(self, s, me):
        return 0.0

def ends(n, s):
    p = pos[n]
    st = SD._state_at(games[str(p["g"])], p["at"])
    seed = SD.BANK + 20000 + 2 * n + s
    agent = Ends(make_agent("mcts-raw:100+learned+phased", seed), samples=8, seed=seed, next_turn=True,
                 research=100, next_search=30)
    agent.ends = []
    agent.search.choose(st)
    line = principal_line(agent.search.last_root)
    cands = restrictions(line)
    agent.outcomes(st, agent.lines_for(st, line, cands), cands)
    return cands, agent.ends

# 1) determinism: full teacher on a few (n, s) against teacher.jsonl
ns = [n for n in sorted(pos) if trows[(n, 0)]["res"]][:3]
for n in ns:
    t = time.process_time()
    gid, at, seed, res = TE.measure((str(pos[n]["g"]), pos[n]["at"], SD.BANK + 20000 + 2 * n, 8, 100, 30, 0))
    same = all(abs(res[k]["teacher"] - v["teacher"]) < 1e-12 for k, v in trows[(n, 0)]["res"].items()) and set(res) == set(trows[(n, 0)]["res"])
    print(f"full teacher n={n} s=0: same as teacher.jsonl {same} ({time.process_time() - t:.2f} CPU s)")
# 2) timing of the own turn only
N = int(sys.argv[2])
t = time.process_time(); tot = 0
for n in sorted(pos)[:N]:
    for s in (0, 1):
        c, e = ends(n, s); tot += len(e)
cpu = time.process_time() - t
print(f"own turn only: {N} positions x 2 seeds, {tot} turn ends, {cpu:.1f} CPU s, {cpu / (2 * N):.2f} CPU s per (position, seed)")
