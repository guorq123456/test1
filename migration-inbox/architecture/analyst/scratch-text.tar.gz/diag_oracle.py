import random
from svsim.cards import decks
from svsim.core.engine import apply, legal_actions, new_game
from svsim.core.enums import Phase
from svsim.core.view import determinize
from svsim.learn.phased import PhasedLearned, matchup_keys
from svsim.learn.features import features, extra_features, names
from svsim.tools.arena import make_agent
from svsim.ui.session import DECKS
ev = PhasedLearned()
for deck, opp in (("ramp-t", "ramp-t"), ("elf-t", "nemesis-t")):
    root = 0.0; diffidx = {}
    for g in range(2):
        agents = [make_agent("greedy+plan+learned", 7 * g + i) for i in range(2)]
        state = new_game(decks.build(DECKS[deck][1]), decks.build(DECKS[opp][1]), seed=900 + g)
        step = 0
        while not state.over:
            me = state.active
            if state.phase == Phase.MAIN and step % 3 == 0:
                for k in range(2):
                    a = determinize(state, me, random.Random(k)); b = determinize(state, me, random.Random(k), oracle=True)
                    for nxt in (False, True):
                        root = max(root, abs(ev.score(a, me, nxt) - ev.score(b, me, nxt)))
                    fa, fb = features(a, me, False, 2), features(b, me, False, 2)
                    nm = names(False, 2)
                    for i, (x, y) in enumerate(zip(fa, fb)):
                        if abs(x - y) > 1e-9:
                            key = (["me_", "op_"][i // len(nm) if i < 2 * len(nm) else 0] + (nm[i % len(nm)] if i < 2 * len(nm) else "const"))
                            diffidx[key] = max(diffidx.get(key, 0), abs(x - y))
            apply(state, agents[me].act(state, legal_actions(state)))
            step += 1
    print(deck, opp, "root max |dscore|", root, "feature diffs", diffidx)
