import json, glob, sys
base='/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/cardtext/'
data={}
tribes={}
for lang in ('en','chs'):
    for f in glob.glob(base+f'set_*_{lang}.json'):
        d=json.load(open(f))['data']
        for k,v in d['card_details'].items():
            data.setdefault(int(k),{})[lang]=v
        for k,v in (d.get('tribe_names') or {}).items():
            tribes.setdefault(lang,{})[k]=v
        for k,v in (d.get('specific_effect_card_info') or {}).items() if isinstance(d.get('specific_effect_card_info'),dict) else []:
            pass
for a in sys.argv[1:]:
    cid=int(a)
    if cid not in data:
        print(cid,'NOT FOUND'); continue
    for lang in ('en','chs'):
        c=data[cid][lang]['common']; e=data[cid][lang].get('evo') or {}
        print(cid, lang, c['name'], 'cost',c['cost'],'atk',c['atk'],'life',c['life'],'type',c['type'],'class',c['class'],'tribes',[tribes.get(lang,{}).get(str(t),t) for t in c['tribes']],'token',c['is_token'])
        print('  TEXT:', c['skill_text'].replace('\n',' / '))
        if e: print('  EVO :', (e.get('skill_text') or '').replace('\n',' / '), 'evo atk/life', e.get('atk'), e.get('life'))
        for q in c.get('questions') or []: print('  QA:', q)
