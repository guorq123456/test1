import json, sys
sys.path.insert(0, "/home/user/test1/analysis/card-value")
import student_data as SD, teacher_eval as TE
D = sys.argv[1]
games = {str(r["g"]): r for r in SD._lines(D + "/selfplay.jsonl")}
pos = {p["n"]: p for p in SD._lines(D + "/positions.jsonl")}
trows = {(r["n"], r["s"]): r for r in SD._lines(D + "/teacher.jsonl")}
TE.GAMES.update(games)
order = [int(x) for x in sys.argv[2].split(",")]
for n in order:
    gid, at, seed, res = TE.measure((str(pos[n]["g"]), pos[n]["at"], SD.BANK + 20000 + 2 * n, 8, 100, 30, 0))
    ref = trows[(n, 0)]["res"]
    diff = {k: (round(res.get(k, {}).get("teacher", float('nan')), 4), round(v["teacher"], 4)) for k, v in ref.items()
            if abs(res.get(k, {}).get("teacher", 9) - v["teacher"]) > 1e-12}
    print(n, "keys same:", set(res) == set(ref), "| differing (mine, RC):", diff)
