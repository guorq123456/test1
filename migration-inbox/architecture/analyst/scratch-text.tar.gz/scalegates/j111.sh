#!/bin/bash
# J111 (README; net and code 9425eee): net-gen4-59000 + eot vs gen3-30000 + eot, both N = 100, ramp-t mirror, 72400000-299
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/bqi1gobpr.output
until grep -q "loop-end" $O; do sleep 15; done
while pgrep -f "svsim[.]learn[.]scaledata" >/dev/null; do sleep 5; done
cat $O
cd $S/wt_eot
export PYTHONPATH=$S/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
$G --a "mcts:100+$P+setnet=analysis/scaling/models/net-gen4-59000.npz+neteot" --b "mcts:100+$P+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot" --max 600 --seed 72400000 --out $S/j111/gate_j111.jsonl > $S/j111/gate_j111.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j111/gate_j111.jsonl > $S/j111/gate_j111_pooled.txt 2>&1
echo "done J111"
