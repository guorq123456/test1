#!/bin/bash
# next cycle (README 45212fb): ramp-t PUCT self-play 20 x 500 from 75400000 (k = 19 held out), code 72a5148; first the cross-machine sample elf-t 75500000 g 0-2
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_puct
export PYTHONPATH=$S/wt_puct
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
M=analysis/scaling/models
python3 -m svsim.tools.host svsim.learn.scaledata play --base 75500000 --stride 2 --shards 0 1 --per-shard 3 --deck elf-t --opponent elf-t \
  --agent "mcts:71+$P+setnet=$M/net-elft-gen2-19500.npz+neteot+puct=$M/prior-elft-ft-t05.npz:2:1" --workers 3 --out $S/sp5/xcheck_elft > $S/sp5/xcheck_elft.log 2>&1
echo "xcheck done"
python3 -m svsim.tools.host svsim.learn.scaledata play --base 75400000 --stride 2 --shards 0 20 --per-shard 500 --deck ramp-t --opponent ramp-t \
  --agent "mcts:88+$P+setnet=$M/net-gen3-30000.npz+neteot+puct=$M/prior-ramp-ft-t05.npz:2:1" --workers 4 --out $S/sp5/ramp > $S/sp5/ramp.log 2>&1
echo "ramp self-play done"
