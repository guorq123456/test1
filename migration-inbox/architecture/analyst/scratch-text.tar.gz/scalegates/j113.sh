#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
NET="setnet=analysis/scaling/models/net-elft-10000.npz+neteot"
B="mcts:200+$P"
G="python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3"
$G --a "mcts:100+$P+$NET" --b "$B" --max 120 --seed 72698000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n100.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n100.log 2>&1
$G --a "mcts:160+$P+$NET" --b "$B" --max 120 --seed 72697000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n160.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n160.log 2>&1
N0=$(python3 - <<PY
import json, subprocess
r100 = float(subprocess.check_output(["python3", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/ratio.py", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n100.jsonl"]))
r160 = float(subprocess.check_output(["python3", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/ratio.py", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/time_n160.jsonl"]))
c = (r160 - r100) / 60
F = r100 - 100 * c
n0 = round((1 - F) / c) if c > 0 else round(100 / r100)
json.dump({"r100": r100, "r160": r160, "c": c, "F": F, "N0": n0, "degenerate": c <= 0}, open("/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/fit.json", "w"), indent=1)
print(n0)
PY
)
$G --a "mcts:$N0+$P+$NET" --b "$B" --max 40 --seed 72699000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/ncheck_j113.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/ncheck_j113.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/ratio.py", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/ncheck_j113.jsonl"]))
n0 = $N0
n = n0 if 0.97 <= q <= 1.03 else round(n0 / q)
json.dump({"N0": n0, "check_ratio": q, "N": n}, open("/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$NET" --b "$B" --max 600 --seed 72600000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/gate_j113.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/gate_j113.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/gate_j113.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j113/gate_j113_pooled.txt 2>&1
echo "done N0=$N0 N=$N"
