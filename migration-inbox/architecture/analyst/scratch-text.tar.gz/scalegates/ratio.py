import json, sys
rows = [json.loads(l) for l in open(sys.argv[1]) if l.strip()]
at = sum(x["total"] for r in rows for x in r["ms"]); an = sum(x["n"] for r in rows for x in r["ms"])
bt = sum(x["total"] for r in rows for x in r["ms_b"]); bn = sum(x["n"] for r in rows for x in r["ms_b"])
print((at / an) / (bt / bn))
