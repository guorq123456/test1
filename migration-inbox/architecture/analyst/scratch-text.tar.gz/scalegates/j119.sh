#!/bin/bash
# J119 (README ae44936; pre-checks in the commit before this run): net-in2a vs gen4-59000, check 73599000-019 from N = 100, gate 73500000-299; code 5158530
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_in2a
export PYTHONPATH=$S/wt_in2a
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
A2="setnet=analysis/scaling/models/net-in2a-59000.npz+neteot"
B="mcts:100+$P+setnet=analysis/scaling/models/net-gen4-59000.npz+neteot"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
$G --a "mcts:100+$P+$A2" --b "$B" --max 40 --seed 73599000 --out $S/j119/ncheck_j119.jsonl > $S/j119/ncheck_j119.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j119/ncheck_j119.jsonl"]))
n = 100 if 0.97 <= q <= 1.03 else round(100 / q)
json.dump({"N0": 100, "check_ratio": q, "N": n}, open("$S/j119/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$A2" --b "$B" --max 600 --seed 73500000 --out $S/j119/gate_j119.jsonl > $S/j119/gate_j119.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j119/gate_j119.jsonl > $S/j119/gate_j119_pooled.txt 2>&1
echo "done J119 N=$N"
