#!/bin/bash
# J116 (check 73099000-019, gate 73000000-299) and J117 (two-point timing 73198000 / 73197000, check 73199000-019, gate 73100000-299)
# README 75f702e / 613aa12; code 342cc14
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/bxz4l011b.output
until grep -q "loop-end" $O; do sleep 15; done
while pgrep -f "svsim[.]learn[.]scaledata" >/dev/null; do sleep 5; done
cat $O
cd $S/wt_in2
export PYTHONPATH=$S/wt_in2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
IN2="setnet=analysis/scaling/models/net-in2-59000.npz+neteot"
KC="setnet=analysis/scaling/models/net-in2kc-59000.npz+neteot"
B="mcts:100+$P+setnet=analysis/scaling/models/net-gen4-59000.npz+neteot"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
R="python3 $S/scalegates/ratio.py"
# J116
$G --a "mcts:100+$P+$IN2" --b "$B" --max 40 --seed 73099000 --out $S/j116/ncheck_j116.jsonl > $S/j116/ncheck_j116.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j116/ncheck_j116.jsonl"]))
n = 100 if 0.97 <= q <= 1.03 else round(100 / q)
json.dump({"N0": 100, "check_ratio": q, "N": n}, open("$S/j116/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$IN2" --b "$B" --max 600 --seed 73000000 --out $S/j116/gate_j116.jsonl > $S/j116/gate_j116.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j116/gate_j116.jsonl > $S/j116/gate_j116_pooled.txt 2>&1
echo "done J116 N=$N"
# J117
$G --a "mcts:100+$P+$KC" --b "$B" --max 120 --seed 73198000 --out $S/j117/time_n100.jsonl > $S/j117/time_n100.log 2>&1
$G --a "mcts:160+$P+$KC" --b "$B" --max 120 --seed 73197000 --out $S/j117/time_n160.jsonl > $S/j117/time_n160.log 2>&1
N0=$(python3 - <<PY
import json, subprocess
r100 = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j117/time_n100.jsonl"]))
r160 = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j117/time_n160.jsonl"]))
c = (r160 - r100) / 60
F = r100 - 100 * c
n0 = round((1 - F) / c) if c > 0 else round(100 / r100)
json.dump({"r100": r100, "r160": r160, "c": c, "F": F, "N0": n0, "degenerate": c <= 0}, open("$S/j117/fit.json", "w"), indent=1)
print(n0)
PY
)
$G --a "mcts:$N0+$P+$KC" --b "$B" --max 40 --seed 73199000 --out $S/j117/ncheck_j117.jsonl > $S/j117/ncheck_j117.log 2>&1
N7=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j117/ncheck_j117.jsonl"]))
n0 = $N0
n = n0 if 0.97 <= q <= 1.03 else round(n0 / q)
json.dump({"N0": n0, "check_ratio": q, "N": n}, open("$S/j117/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N7+$P+$KC" --b "$B" --max 600 --seed 73100000 --out $S/j117/gate_j117.jsonl > $S/j117/gate_j117.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j117/gate_j117.jsonl > $S/j117/gate_j117_pooled.txt 2>&1
echo "done J117 N0=$N0 N=$N7"
