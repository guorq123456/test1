#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
NET="setnet=analysis/scaling/models/net-gen2-20000.npz+neteot"
B="mcts:200+$P"
python3 -m svsim.tools.host svsim.tools.gate --a "mcts:138+$P+$NET" --b "$B" --deck ramp-t --opponent ramp-t --fixed --max 40 --seed 70999000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98.log 2>&1
N=$(python3 - <<'PY'
import json
rows=[json.loads(l) for l in open("/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98.jsonl")]
at=sum(x["total"] for r in rows for x in r["ms"]); an=sum(x["n"] for r in rows for x in r["ms"])
bt=sum(x["total"] for r in rows for x in r["ms_b"]); bn=sum(x["n"] for r in rows for x in r["ms_b"])
ratio=(at/an)/(bt/bn)
N=138 if 0.97<=ratio<=1.03 else round(138/ratio)
json.dump({"ms_A":at/an,"ms_B":bt/bn,"ratio":ratio,"N":N,"decisions_A":an,"decisions_B":bn},open("/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98_ratio.json","w"),indent=1)
print(N)
PY
)
echo "N=$N" >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98.log
python3 -m svsim.tools.host svsim.tools.gate --a "mcts:$N+$P+$NET" --b "$B" --deck ramp-t --opponent ramp-t --fixed --max 600 --seed 70900000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/gate_j98.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/gate_j98.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/gate_j98.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/gate_j98_pooled.txt 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j98/ncheck_j98_pooled.txt 2>&1
echo done
