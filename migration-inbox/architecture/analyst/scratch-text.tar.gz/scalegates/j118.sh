#!/bin/bash
# J118 (README 55d3d07): two-point timing of the faster setnet path (33a8495) against v2skx, ramp-t (gen3) and elf-t (net-elft-10000)
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_fast
export PYTHONPATH=$S/wt_fast
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
B="mcts:200+$P"
fit() {  # deck net t100seed t160seed checkseed dir
  local deck=$1 NET="setnet=analysis/scaling/models/$2.npz+neteot" d=$S/j118/$6
  mkdir -p $d
  G="python3 -m svsim.tools.host svsim.tools.gate --deck $deck --opponent $deck --fixed --workers 3"
  $G --a "mcts:100+$P+$NET" --b "$B" --max 120 --seed $3 --out $d/time_n100.jsonl > $d/time_n100.log 2>&1
  $G --a "mcts:160+$P+$NET" --b "$B" --max 120 --seed $4 --out $d/time_n160.jsonl > $d/time_n160.log 2>&1
  N0=$(python3 - <<PY
import json, subprocess
r100 = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$d/time_n100.jsonl"]))
r160 = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$d/time_n160.jsonl"]))
c = (r160 - r100) / 60
F = r100 - 100 * c
n0 = round((1 - F) / c) if c > 0 else round(100 / r100)
json.dump({"r100": r100, "r160": r160, "c": c, "F": F, "N0": n0, "degenerate": c <= 0}, open("$d/fit.json", "w"), indent=1)
print(n0)
PY
)
  $G --a "mcts:$N0+$P+$NET" --b "$B" --max 40 --seed $5 --out $d/ncheck.jsonl > $d/ncheck.log 2>&1
  python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$d/ncheck.jsonl"]))
n0 = $N0
n = n0 if 0.97 <= q <= 1.03 else round(n0 / q)
json.dump({"N0": n0, "check_ratio": q, "N": n}, open("$d/check.json", "w"), indent=1)
print("$deck", "N0", n0, "check", round(q, 4), "N", n)
PY
}
fit ramp-t net-gen3-30000 73298000 73297000 73299000 ramp
fit elf-t net-elft-10000 73296000 73295000 73294000 elf
echo done
