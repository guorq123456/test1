#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_net
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_net
B="mcts:200+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
for pair in "1000 70300000" "10000 70400000"; do
  set -- $pair
  python3 -m svsim.tools.host svsim.tools.gate --a "mcts:128+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-$1.npz" --b "$B" --deck ramp-t --opponent ramp-t --fixed --max 600 --seed $2 --workers 3 --out /home/user/test1/analysis/gates/scaling/gate_$1.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/gate_$1.log 2>&1
  python3 /home/user/test1/analysis/oracle-hand/pooled.py /home/user/test1/analysis/gates/scaling/gate_$1.jsonl > /home/user/test1/analysis/gates/scaling/gate_$1_pooled.txt 2>&1
done
echo done
