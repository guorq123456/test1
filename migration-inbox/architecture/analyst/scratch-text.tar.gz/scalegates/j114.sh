#!/bin/bash
# J114: elf-t confirmation gate (README, registered 87e9232). Check at N = 96 (72799000-019), fix once, gate 72700000-299.
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eot
export PYTHONPATH=$S/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
NET="setnet=analysis/scaling/models/net-elft-10000.npz+neteot"
B="mcts:200+$P"
G="python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3"
$G --a "mcts:96+$P+$NET" --b "$B" --max 40 --seed 72799000 --out $S/j114/ncheck_j114.jsonl > $S/j114/ncheck_j114.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j114/ncheck_j114.jsonl"]))
n = 96 if 0.97 <= q <= 1.03 else round(96 / q)
json.dump({"N0": 96, "check_ratio": q, "N": n}, open("$S/j114/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$NET" --b "$B" --max 600 --seed 72700000 --out $S/j114/gate_j114.jsonl > $S/j114/gate_j114.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j114/gate_j114.jsonl > $S/j114/gate_j114_pooled.txt 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j113/gate_j113.jsonl $S/j114/gate_j114.jsonl > $S/j114/pooled_j113_j114.txt 2>&1
echo "done J114 N=$N"
