#!/bin/bash
# elf-t generation-3 self-play on the analysis machine (README 827c234): shards given as arguments, 500 games each at 74100000 + 2k
# one shard at a time; touch /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elf3rec/STOP to stop at the next shard boundary
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
A="mcts:200+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-elft-gen2-19500.npz+neteot"
for k in "$@"; do
  [ -e $S/elf3rec/STOP ] && { echo "stopped before shard $k"; break; }
  [ -e $S/elf3rec/rec-$((74100000 + 2*k)).jsonl.gz ] && continue
  python3 -m svsim.learn.scaledata play --base 74100000 --stride 2 --per-shard 500 --shards $k $((k+1)) --agent "$A" --deck elf-t --opponent elf-t --workers 4 --out $S/elf3rec >> $S/scalegates/elf3.log 2>&1
  echo "shard $k exit $?"
done
echo loop-end
