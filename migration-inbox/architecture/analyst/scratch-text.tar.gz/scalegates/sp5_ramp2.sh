#!/bin/bash
# ramp-t PUCT self-play, resumed for k = 15-16 only (k = 17-19 handed to the builder line); code 72a5148
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_puct
export PYTHONPATH=$S/wt_puct
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
M=analysis/scaling/models
python3 -m svsim.tools.host svsim.learn.scaledata play --base 75400000 --stride 2 --shards 15 17 --per-shard 500 --deck ramp-t --opponent ramp-t \
  --agent "mcts:88+$P+setnet=$M/net-gen3-30000.npz+neteot+puct=$M/prior-ramp-ft-t05.npz:2:1" --workers 4 --out $S/sp5/ramp > $S/sp5/ramp2.log 2>&1
echo "ramp k 15-16 done"
