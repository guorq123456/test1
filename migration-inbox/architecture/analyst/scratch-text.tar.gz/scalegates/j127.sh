#!/bin/bash
# J127 (README 8a51935): J126's confirmation gate, ramp-t, A = gen3 + eot + screen=0:1000:4 N 154 (fixed), B = gen3 N 120 + eot, 74400000-299; code d884a3c
# runs alongside self-play (architecture thread 07:31Z): N fixed both sides, in-gate ratio recorded but load-affected
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot"
python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3 \
  --a "mcts:154+$P+screen=0:1000:4" --b "mcts:120+$P" --max 600 --seed 74400000 --out $S/j127/gate_j127.jsonl > $S/j127/gate_j127.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j127/gate_j127.jsonl > $S/j127/gate_j127_pooled.txt 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j126/gate_j126.jsonl $S/j127/gate_j127.jsonl > $S/j127/pooled_j126_j127.txt 2>&1
echo "done J127"
