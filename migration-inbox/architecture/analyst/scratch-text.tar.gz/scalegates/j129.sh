#!/bin/bash
# J129 (README 8a1cf5e; pre-checks in the commit before this run): elft-gen3 vs elft-gen2, both N 110 + eot, elf-t, 74600000-299; code 81e3b3f
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eg3
export PYTHONPATH=$S/wt_eg3
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3 \
  --a "mcts:110+$P+setnet=analysis/scaling/models/net-elft-gen3-29000.npz+neteot" \
  --b "mcts:110+$P+setnet=analysis/scaling/models/net-elft-gen2-19500.npz+neteot" \
  --max 600 --seed 74600000 --out $S/j129/gate_j129.jsonl > $S/j129/gate_j129.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j129/gate_j129.jsonl > $S/j129/gate_j129_pooled.txt 2>&1
echo "done J129"
