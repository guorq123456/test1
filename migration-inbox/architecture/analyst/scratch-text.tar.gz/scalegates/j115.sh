#!/bin/bash
# J115 (README, registered 015dd83): gen3-30000 + eot at 200 vs the same at 100, ramp-t mirror, 72900000-299, not compute-matched
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/bdivh3mif.output
until grep -q "loop-end" $O; do sleep 15; done
while pgrep -f "svsim[.]learn[.]scaledata" >/dev/null; do sleep 5; done
cat $O
cd $S/wt_eot
export PYTHONPATH=$S/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
$G --a "mcts:200+$P" --b "mcts:100+$P" --max 600 --seed 72900000 --out $S/j115/gate_j115.jsonl > $S/j115/gate_j115.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j115/gate_j115.jsonl > $S/j115/gate_j115_pooled.txt 2>&1
echo "done J115"
