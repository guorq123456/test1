#!/bin/bash
# one shard at a time; touch /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4rec/STOP to stop at the next shard boundary
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
A="mcts:200+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-100000.npz+neteot"
for k in 0 1 2 3 4 5 6 7 8 9; do
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4rec/STOP ] && { echo "stopped before shard $k"; break; }
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4rec/rec-$((71500000 + 2*k)).jsonl.gz ] && continue
  python3 -m svsim.learn.scaledata play --base 71500000 --stride 2 --shards $k $((k+1)) --agent "$A" --deck ramp-t --opponent ramp-t --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4rec >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/gen4.log 2>&1
  echo "shard $k exit $?"
done
echo loop-end
