#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_net
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_net
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
B="mcts:200+$P"
python3 -m svsim.tools.host svsim.tools.gate --a "mcts:200+$P+setnet=analysis/scaling/models/net-10000.npz" --b "$B" --deck ramp-t --opponent ramp-t --fixed --max 600 --seed 70600000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_d1.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_d1.log 2>&1
python3 -m svsim.tools.host svsim.tools.gate --a "mcts:128+$P" --b "$B" --deck ramp-t --opponent ramp-t --fixed --max 600 --seed 70700000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_d2.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_d2.log 2>&1
for d in d1 d2; do python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_$d.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/diag_${d}_pooled.txt 2>&1; done
echo done
