#!/bin/bash
# elf-t generation-2 self-play on the analysis machine (README, registered 87e9232): k = 0..9, 500 games each at 72800000 + 2k
# one shard at a time; touch /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elf2rec/STOP to stop at the next shard boundary
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eot
export PYTHONPATH=$S/wt_eot
A="mcts:200+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-elft-10000.npz+neteot"
for k in "$@"; do
  [ -e $S/elf2rec/STOP ] && { echo "stopped before shard $k"; break; }
  [ -e $S/elf2rec/rec-$((72800000 + 2*k)).jsonl.gz ] && continue
  python3 -m svsim.learn.scaledata play --base 72800000 --stride 2 --per-shard 500 --shards $k $((k+1)) --agent "$A" --deck elf-t --opponent elf-t --workers 4 --out $S/elf2rec >> $S/scalegates/elf2.log 2>&1
  echo "shard $k exit $?"
done
echo loop-end
