#!/bin/bash
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
python3 -m svsim.tools.host svsim.tools.gate --a "mcts:100+$P+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot" --b "mcts:200+$P" --deck ramp-t --opponent ramp-t --fixed --max 600 --seed 70900000 --workers 3 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j102/gate_j102.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j102/gate_j102.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j102/gate_j102.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j102/gate_j102_pooled.txt 2>&1
echo done
