#!/bin/bash
# J125 (README ba22775): elft-gen2 + eot at J121's N (110) vs v2skx, elf-t, 74200000-299, no check; code d884a3c
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3 \
  --a "mcts:110+$P+setnet=analysis/scaling/models/net-elft-gen2-19500.npz+neteot" --b "mcts:200+$P" \
  --max 600 --seed 74200000 --out $S/j125/gate_j125.jsonl > $S/j125/gate_j125.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j125/gate_j125.jsonl > $S/j125/gate_j125_pooled.txt 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j121/gate_j121.jsonl $S/j125/gate_j125.jsonl > $S/j125/pooled_j121_j125.txt 2>&1
echo "done J125"
