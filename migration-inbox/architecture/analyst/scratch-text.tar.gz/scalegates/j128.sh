#!/bin/bash
# J128 (README 8a51935): elf-t, elft-gen2 + eot + screen=0:1000:4 vs elft-gen2 + eot N 110; check 74599000-019 from N = 137 on an idle machine, gate 74500000-299; code d884a3c
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/beiqde02x.output
until grep -q "loop-end" $O; do sleep 15; done
while pgrep -f "svsim[.]learn[.]scaledata|svsim[.]tools[.]gate|d6_lethal" >/dev/null; do sleep 5; done
cat $O
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-elft-gen2-19500.npz+neteot"
B="mcts:110+$P"
G="python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3"
$G --a "mcts:137+$P+screen=0:1000:4" --b "$B" --max 40 --seed 74599000 --out $S/j128/ncheck_j128.jsonl > $S/j128/ncheck_j128.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j128/ncheck_j128.jsonl"]))
n = 137 if 0.97 <= q <= 1.03 else round(137 / q)
json.dump({"N0": 137, "check_ratio": q, "N": n}, open("$S/j128/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+screen=0:1000:4" --b "$B" --max 600 --seed 74500000 --out $S/j128/gate_j128.jsonl > $S/j128/gate_j128.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j128/gate_j128.jsonl > $S/j128/gate_j128_pooled.txt 2>&1
echo "done J128 N=$N"
