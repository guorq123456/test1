#!/bin/bash
# generation 4 top-up on the analysis machine: finish the builder's k = 4 from its part file, then k = 28..39
# one shard at a time; touch /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4xrec/STOP to stop at the next shard boundary
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
A="mcts:200+plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot"
for k in 4 28 29 30 31 32 33 34 35 36 37 38 39 20 21 22 23 24 25 26 27; do
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4xrec/STOP ] && { echo "stopped before shard $k"; break; }
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4xrec/rec-$((72300000 + 2*k)).jsonl.gz ] && continue
  python3 -m svsim.learn.scaledata play --base 72300000 --stride 2 --per-shard 500 --shards $k $((k+1)) --agent "$A" --deck ramp-t --opponent ramp-t --workers 4 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/gen4xrec >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/gen4x.log 2>&1
  echo "shard $k exit $?"
done
echo loop-end
