#!/bin/bash
# J121 (README c9fe37a / 79d99eb): elft-gen2 + eot vs v2skx, elf-t, check 73799000-019 from N = 105, gate 73700000-299; code d884a3c
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
NET="setnet=analysis/scaling/models/net-elft-gen2-19500.npz+neteot"
B="mcts:200+$P"
G="python3 -m svsim.tools.host svsim.tools.gate --deck elf-t --opponent elf-t --fixed --workers 3"
$G --a "mcts:105+$P+$NET" --b "$B" --max 40 --seed 73799000 --out $S/j121/ncheck_j121.jsonl > $S/j121/ncheck_j121.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j121/ncheck_j121.jsonl"]))
n = 105 if 0.97 <= q <= 1.03 else round(105 / q)
json.dump({"N0": 105, "check_ratio": q, "N": n}, open("$S/j121/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$NET" --b "$B" --max 600 --seed 73700000 --out $S/j121/gate_j121.jsonl > $S/j121/gate_j121.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j121/gate_j121.jsonl > $S/j121/gate_j121_pooled.txt 2>&1
echo "done J121 N=$N"
