#!/bin/bash
# J126 (README 3444243 + the option note): ramp-t, gen3 + eot with the far lethal screen off vs gen3 N 120 + eot; check 74399000-019 from N = 154, gate 74300000-299; code d884a3c
S=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/b0qsamx54.output
until grep -q "done J125" $O; do sleep 15; done
while pgrep -f "svsim[.]tools[.]gate" >/dev/null; do sleep 5; done
cd $S/wt_eg2
export PYTHONPATH=$S/wt_eg2
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost+setnet=analysis/scaling/models/net-gen3-30000.npz+neteot"
B="mcts:120+$P"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
$G --a "mcts:154+$P+screen=0:1000:4" --b "$B" --max 40 --seed 74399000 --out $S/j126/ncheck_j126.jsonl > $S/j126/ncheck_j126.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "$S/scalegates/ratio.py", "$S/j126/ncheck_j126.jsonl"]))
n = 154 if 0.97 <= q <= 1.03 else round(154 / q)
json.dump({"N0": 154, "check_ratio": q, "N": n}, open("$S/j126/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+screen=0:1000:4" --b "$B" --max 600 --seed 74300000 --out $S/j126/gate_j126.jsonl > $S/j126/gate_j126.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py $S/j126/gate_j126.jsonl > $S/j126/gate_j126_pooled.txt 2>&1
echo "done J126 N=$N"
