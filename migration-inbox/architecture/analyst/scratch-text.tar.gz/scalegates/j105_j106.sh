#!/bin/bash
O=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/tasks/b5ed2l389.output
until grep -q "loop-end" $O; do sleep 15; done
while pgrep -f "svsim[.]learn[.]scaledata" >/dev/null; do sleep 5; done
cat $O
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_eot
P="plan+learned+phased=pkg-kc-ramp-ramp+xprune=3:3:cost"
G3="setnet=analysis/scaling/models/net-gen3-30000.npz+neteot"
NX="setnet=analysis/scaling/models/net-100000.npz+neteot"
G="python3 -m svsim.tools.host svsim.tools.gate --deck ramp-t --opponent ramp-t --fixed --workers 3"
# J105
$G --a "mcts:100+$P+$G3" --b "mcts:100+$P+$NX" --max 600 --seed 71700000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j105/gate_j105.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j105/gate_j105.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j105/gate_j105.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j105/gate_j105_pooled.txt 2>&1
# J106
$G --a "mcts:100+$P+$G3" --b "mcts:200+$P" --max 40 --seed 71899000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/ncheck_j106.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/ncheck_j106.log 2>&1
N=$(python3 - <<PY
import json, subprocess
q = float(subprocess.check_output(["python3", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/ratio.py", "/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/ncheck_j106.jsonl"]))
n = 100 if 0.97 <= q <= 1.03 else round(100 / q)
json.dump({"N0": 100, "check_ratio": q, "N": n}, open("/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/check.json", "w"), indent=1)
print(n)
PY
)
$G --a "mcts:$N+$P+$G3" --b "mcts:200+$P" --max 600 --seed 71800000 --out /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/gate_j106.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/gate_j106.log 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/gate_j106.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/gate_j106_pooled.txt 2>&1
python3 /home/user/test1/analysis/oracle-hand/pooled.py /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j102/gate_j102.jsonl /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/gate_j106.jsonl > /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/j106/pooled_j102_j106.txt 2>&1
echo "done J106 N=$N"
