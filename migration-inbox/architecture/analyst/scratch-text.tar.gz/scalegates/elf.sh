#!/bin/bash
# training shards then holdout shards, one at a time; touch /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfrec/STOP to stop at the next shard boundary
cd /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_elf
export PYTHONPATH=/tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/wt_elf
run() {  # base k dir
  [ -e /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfrec/STOP ] && { echo "stopped before $1 shard $2"; exit 0; }
  [ -e $3/rec-$(($1 + 2*$2)).jsonl.gz ] && return
  python3 -m svsim.learn.scaledata play --base $1 --stride 2 --shards $2 $(($2+1)) --deck elf-t --opponent elf-t --workers 4 --out $3 >> /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/scalegates/elf.log 2>&1
  echo "base $1 shard $2 exit $?"
}
for k in 0 1 2 3 4 5 6 7 8 9; do run 71900000 $k /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfrec; done
for h in 0 1 2 3 4; do run 72000000 $h /tmp/claude-0/-home-user-test1/cf6df9ad-c705-526d-b63f-e3d01c619a8e/scratchpad/elfheld; done
echo loop-end
