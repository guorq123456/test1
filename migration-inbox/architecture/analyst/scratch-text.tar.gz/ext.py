import json,sys,re
s=open(sys.argv[1]).read()
i=s.index('{"ccr"'); j=s.rindex('}}')+2
d=json.loads(s[i:j])['ccr']['data']
for e in d:
    t=e['created_at'][5:19]
    for role in ('user','assistant'):
        if role not in e: continue
        c=e[role].get('internal_anthropic_catchall',{})
        syn=c.get('isSynthetic')
        content=c.get('message',{}).get('content')
        if isinstance(content,str): content=[{'type':'text','text':content}]
        for b in content or []:
            if b.get('type')=='text':
                print(f"[{t}] {role.upper()}{' (synthetic)' if syn else ''}: {b['text'][:3000]}\n")
            elif b.get('type')=='tool_use':
                inp=b.get('input',{})
                print(f"[{t}]   tool {b.get('name')}: {inp.get('description') or str(inp)[:150]}")
            elif b.get('type')=='tool_result':
                pass
