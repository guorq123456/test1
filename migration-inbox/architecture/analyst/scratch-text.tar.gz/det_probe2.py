import json, sys, random
sys.path.insert(0, "/home/user/test1/analysis/card-value")
import student_data as SD, teacher_eval as TE
from multiprocessing import Pool
D = sys.argv[1]
games = {str(r["g"]): r for r in SD._lines(D + "/selfplay.jsonl")}
pos = {p["n"]: p for p in SD._lines(D + "/positions.jsonl")}
trows = {(r["n"], r["s"]): r for r in SD._lines(D + "/teacher.jsonl")}
def init(g): TE.GAMES.update(g)
def job(ns):
    n, s = ns
    gid, at, seed, res = TE.measure((str(pos[n]["g"]), pos[n]["at"], SD.BANK + 20000 + 2 * n + s, 8, 100, 30, 0))
    ref = trows[(n, s)]["res"]
    d = [abs(res.get(k, {}).get("teacher", 9) - v["teacher"]) for k, v in ref.items()]
    return n, s, set(res) == set(ref), max(d) if d else 0.0, len(ref)
if __name__ == "__main__":
    rng = random.Random(1)
    picks = rng.sample([(n, s) for n in pos for s in (0, 1) if trows[(n, s)]["res"]], 40)
    with Pool(4, initializer=init, initargs=(games,)) as p:
        out = p.map(job, picks)
    same = [o for o in out if o[2] and o[3] < 1e-12]
    print(f"{len(same)}/{len(out)} (position, seed) identical to RC; differing ones (n, s, keys same, max |dT|):")
    for o in out:
        if not (o[2] and o[3] < 1e-12): print("  ", o[:4])
