"""Claude plays Rhinoceroach Forest against the web page's "strong" Ramp Dragon.

Only what a player sees is printed (svsim.ui.session.Session.view: own hand,
both boards, counts, the public log). Each call replays the saved record.

    cplay.py new N            start game N (seed 880000+N; odd N: Claude first)
    cplay.py mull N i j ...   mulligan the hand cards at these indices (none: keep)
    cplay.py act N A B ...    play actions in order: '#k' = index k in the last
                              list, or the exact action text; stops early when a
                              card is drawn or something random happens, or an
                              action isn't legal any more
    cplay.py show N           print the view again
"""
from svsim.cards import library as _lib, decks as _decks  # register every card script
import json, sys
from pathlib import Path
from svsim.ui.session import Session

GAMES = Path(__file__).resolve().parent / "games"


def path(n):
    return GAMES / f"g{n}.json"


def load(n):
    d = json.loads(path(n).read_text(encoding="utf-8"))
    s = Session()
    s.resume(d["record"])
    return s, d


def save(n, s, d):
    d["record"] = s.record_data()
    path(n).write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")


def run_ai(s):
    while not s.state.over and s.state.active == 1:
        s.ai_step()


def card(c, field=False):
    t = f"{c['name']}"
    if "atk" in c:
        t += f" {c['atk']}/{c['life']}" + (f"(上限{c['max_life']})" if c['life'] < c['max_life'] else "")
    if c.get("evolved"):
        t += " 超进化" if c["evolved"] == 2 else " 进化"
    if c.get("keywords"):
        t += f" [{c['keywords']}]"
    if c.get("countdown") is not None:
        t += f" 倒数{c['countdown']}"
    if field and c.get("status"):
        t += f" <{c['status']}>"
    return t


def show(s, d):
    v = s.view()
    log = s.log
    seen = d.get("seen", 0)
    new = [x for x in log[seen:] if not str(x).startswith("继续")]
    d["seen"] = len(log)
    if new:
        print("【新动态】\n  " + "\n  ".join(str(x) for x in new[-40:]))
    me, ai = v["you"], v["ai"]
    print(f"\n=== 第 {v['turn']} 回合 {'(轮到你)' if v['active'] == 0 else ''} ===")
    print(f"AI  : 血 {ai['hp']}/{ai['max_hp']}  PP {ai['pp']}/{ai['max_pp']}  进化点 {ai['ep']} 超进化点 {ai['sep']}  "
          f"手牌 {ai['hand_count']}  牌库 {ai['deck']}" + (f"  主战者区 {[card(c) for c in ai['leader_area']]}" if ai['leader_area'] else ""))
    print("     场上: " + ("；".join(card(c, True) for c in ai["field"]) or "（空）"))
    print(f"你  : 血 {me['hp']}/{me['max_hp']}  PP {me['pp']}/{me['max_pp']}  进化点 {me['ep']} 超进化点 {me['sep']}  "
          f"连击 {me['combo']}  牌库 {me['deck']}  墓地 {me['grave']}" + ("  额外能量点可用" if me['bonus'] else "")
          + (f"  主战者区 {[card(c) for c in me['leader_area']]}" if me['leader_area'] else ""))
    print("     场上: " + ("；".join(card(c, True) for c in me["field"]) or "（空）"))
    print("     手牌: " + "；".join(f"[{i}] {c['cost']}费 {card(c)}" for i, c in enumerate(me.get("hand", []))))
    if v["over"]:
        print(f"\n*** 对局结束：{'你赢了' if v['winner'] == 0 else 'AI 赢了' if v['winner'] == 1 else '平局'} ***  回放码 {v.get('code', '')[:80]}...")
    elif v.get("mulligan"):
        print("\n换牌阶段：mull N 下标...（不换就不写下标）")
    else:
        print("\n可选动作：\n  " + "\n  ".join(f"#{a['i']} {a['text']}" for a in v["actions"]))


def main():
    cmd, n = sys.argv[1], int(sys.argv[2])
    args = sys.argv[3:]
    if cmd == "new":
        GAMES.mkdir(exist_ok=True)
        s = Session()
        s.start("rhino", "ramp", "strong", seed=880000 + n, first="you" if n % 2 else "ai")
        d = {"seen": 0}
        run_ai(s)
    else:
        s, d = load(n)
        if cmd == "mull":
            s.mulligan([int(i) for i in args])
            run_ai(s)
        elif cmd == "act":
            from svsim.search.lethal import hidden_info
            for a in args:
                v = s.view()
                if v["over"] or v["active"] != 0:
                    break
                if a.startswith("#"):
                    idx = int(a[1:])
                else:
                    match = [x["i"] for x in v["actions"] if x["text"] == a]
                    if not match:
                        print(f"!! 找不到动作：{a}（已停下）")
                        break
                    idx = match[0]
                before = (hidden_info(s.state), len(s.state.players[0].hand))
                text = next(x["text"] for x in v["actions"] if x["i"] == idx)
                s.act(idx)
                print(f">> {text}")
                if s.state.active == 1:
                    run_ai(s)
                    break
                if hidden_info(s.state) != before[0]:
                    print("   （抽了牌或有随机结果，先停下看看）")
                    break
    save(n, s, d)
    show(s, d)
    save(n, s, d)


if __name__ == "__main__":
    main()
